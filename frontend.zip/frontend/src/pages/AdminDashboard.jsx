import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getAdminStats, getAllReservations } from '../services/api';
import AdminLayout from '../components/admin/AdminLayout';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, Legend } from 'recharts';

const AdminDashboard = () => {
    const [stats, setStats] = useState({
        totalStalls: 0,
        bookedStalls: 0,
        availableStalls: 0,
        totalRevenue: 0
    });
    const [recentReservations, setRecentReservations] = useState([]);
    const navigate = useNavigate();

    const loadData = async () => {
        try {
            const [statsData, reservationsData] = await Promise.all([
                getAdminStats(),
                getAllReservations()
            ]);
            setStats(statsData);
            
            const allReservations = reservationsData.content || reservationsData || [];
            
            const sorted = [...allReservations].sort((a, b) => b.id - a.id).slice(0, 5);
            setRecentReservations(sorted);

        } catch (error) {
            console.error("Failed to load dashboard data", error);
        }
    };

    useEffect(() => {
        loadData();
    }, []);

    const formatCurrency = (amount) => {
        return new Intl.NumberFormat('en-LK', { style: 'currency', currency: 'LKR' }).format(amount);
    };

    const chartData = [
        { name: 'Booked', value: stats.bookedStalls },
        { name: 'Available', value: stats.availableStalls },
    ];
    const COLORS = ['#F43F5E', '#10B981']; // Rose-500, Emerald-500

    return (
        <AdminLayout>
            {/* Stat Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <StatCard
                    title="Total Revenue"
                    value={formatCurrency(stats.totalRevenue)}
                    color="bg-gradient-to-br from-emerald-500 to-teal-600"
                    icon={
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-emerald-100" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                    }
                />
                <StatCard
                    title="Total Stalls"
                    value={stats.totalStalls}
                    color="bg-gradient-to-br from-blue-500 to-indigo-600"
                    icon={
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-100" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                        </svg>
                    }
                />
                <StatCard
                    title="Booked Stalls"
                    value={stats.bookedStalls}
                    color="bg-gradient-to-br from-rose-500 to-pink-600"
                    icon={
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-rose-100" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                        </svg>
                    }
                />
                <StatCard
                    title="Available Stalls"
                    value={stats.availableStalls}
                    color="bg-gradient-to-br from-amber-500 to-orange-600"
                    icon={
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-amber-100" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                    }
                />
            </div>

            {/* Dashboard Content Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
                
                {/* Left Column: Analytics Chart */}
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex flex-col items-center">
                    <h3 className="text-lg font-bold text-gray-800 self-start mb-4">Stall Availability</h3>
                    <div className="w-full h-64">
                         <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                                <Pie
                                    data={chartData}
                                    cx="50%"
                                    cy="50%"
                                    innerRadius={60}
                                    outerRadius={80}
                                    fill="#8884d8"
                                    paddingAngle={5}
                                    dataKey="value"
                                >
                                    {chartData.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                    ))}
                                </Pie>
                                <RechartsTooltip />
                                <Legend verticalAlign="bottom" height={36}/>
                            </PieChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                {/* Right Column: Recent Reservations */}
                <div className="lg:col-span-2 bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-lg font-bold text-gray-800">Recent Activity</h3>
                        <button 
                            onClick={() => navigate('/admin/reservations')}
                            className="text-indigo-600 hover:text-indigo-800 text-sm font-medium"
                        >
                            View All
                        </button>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-gray-200">
                            <thead>
                                <tr>
                                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Vendor</th>
                                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stalls</th>
                                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-gray-200">
                                {recentReservations.length > 0 ? (
                                    recentReservations.map((res) => (
                                        <tr key={res.id} className="hover:bg-gray-50">
                                            <td className="px-4 py-3 whitespace-nowrap">
                                                <div className="text-sm font-medium text-gray-900">{res.vendor.businessName}</div>
                                            </td>
                                            <td className="px-4 py-3">
                                                 <div className="flex flex-wrap gap-1">
                                                    {res.stalls.map(s => (
                                                        <span key={s.id} className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800">
                                                            {s.name}
                                                        </span>
                                                    ))}
                                                </div>
                                            </td>
                                            <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                                                {new Date(res.reservationDate).toLocaleDateString()}
                                            </td>
                                            <td className="px-4 py-3 whitespace-nowrap">
                                                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                    ${res.status === 'CONFIRMED' ? 'bg-green-100 text-green-800' :
                                                        res.status === 'PENDING' ? 'bg-yellow-100 text-yellow-800' :
                                                            'bg-red-100 text-red-800'}`}>
                                                    {res.status}
                                                </span>
                                            </td>
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td colSpan="4" className="px-4 py-4 text-center text-sm text-gray-500">No recent activity.</td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </AdminLayout>
    );
};

const StatCard = ({ title, value, color, icon }) => (
    <div className={`p-6 rounded-xl shadow-md text-white ${color} relative overflow-hidden group hover:shadow-xl transition-all duration-300`}>
        <div className="absolute right-0 top-0 opacity-10 transform translate-x-4 -translate-y-4 group-hover:scale-110 transition-transform duration-300">
            <svg className="w-24 h-24" fill="currentColor" viewBox="0 0 20 20">
                <circle cx="10" cy="10" r="10" />
            </svg>
        </div>
        <div className="relative z-10 flex justify-between items-start">
            <div>
                <h3 className="text-sm font-medium text-white/80 uppercase tracking-wider">{title}</h3>
                <p className="text-3xl font-bold mt-2">{value}</p>
            </div>
            <div className="p-2 bg-white/20 rounded-lg">
                {icon}
            </div>
        </div>
    </div>
);

export default AdminDashboard;