import React, { Suspense } from 'react';
import Navbar from '../components/Navbar';
import Hero from '../components/Hero';
import SocialProof from '../components/SocialProof';
import Pricing from '../components/Pricing';
import Footer from '../components/Footer';
import { Helmet } from 'react-helmet-async';

// Lazy load the heavy map component
const ExhibitionMap = React.lazy(() => import('../components/ExhibitionMap'));

const LandingPage = () => {
  return (
    <div className="font-sans antialiased text-gray-900 bg-white">
      <Helmet>
        <title>Colombo International Book Fair 2026 | Stall Reservations</title>
        <meta name="description" content="Reserve your stall for the premier literary event of the year. Join publishers, authors, and readers at the Colombo International Book Fair 2026." />
        <meta property="og:title" content="Colombo International Book Fair 2026" />
        <meta property="og:description" content="Reserve your stall for the premier literary event of the year." />
        <meta property="og:type" content="website" />
      </Helmet>

      <Navbar />
      <Hero />
      <SocialProof />

      <section id="overview" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">About the Event</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            The Colombo International Book Fair is the premier literary event in Sri Lanka, bringing together publishers, authors, and readers from around the globe.
          </p>
        </div>
      </section>

      <Pricing />

      <section id="map" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Exhibition Map</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            Explore the layout of the BMICH to find your perfect spot. Green stalls are available for immediate reservation.
          </p>

          <Suspense fallback={<div className="h-96 flex items-center justify-center bg-gray-100 rounded-lg">Loading Map...</div>}>
            <ExhibitionMap />
          </Suspense>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default LandingPage;
