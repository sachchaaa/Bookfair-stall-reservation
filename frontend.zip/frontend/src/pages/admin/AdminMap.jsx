import { useState, useEffect } from 'react';
import api from '../../services/api';
import AdminLayout from '../../components/admin/AdminLayout';

const AdminMap = () => {
    const [stalls, setStalls] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const fetchStalls = async () => {
        try {
            // Ideally we should have a specific endpoint for admin map data that includes vendor info
            // But for now, we can reuse /stalls and maybe enrich it if the backend returns vendor details 
            // Or we just implement the read-only view first.
            // *PLAN UPDATE*: The MD file asked for hover logic. 
            // If the current /stalls endpoint doesn't return vendor info, we need that.
            // But let's check what /stalls returns first. It returns List<Stall>.
            // Stall entity does not have vendor info directly.
            // So we strictly need the new endpoint /admin/map-data for this to work fully.
            // For now, I will use /stalls and if I can't get vendor info yet, I'll display just the status.

            // To make "Hover shows Vendor Name" work, I need to fetch reservations too or a joined view.
            // Let's try fetching all reservations and mapping them to stalls client-side for this MVP step
            // to avoid too many backend changes if I want to stick to the plan's exact modification list.
            // However, the MD file didn't explicitly say "Don't touch backend for map".
            // It said "[NEW] AdminMap.jsx ... Read-only version of StallMap".
            // Let's try to do it right. I'll fetch /reservations via existing getAllReservations logic 
            // and map it here, OR just use the stall status for now.

            const [stallsRes, reservationsRes] = await Promise.all([
                api.get('/stalls'),
                api.get('/admin/reservations?size=1000') // Fetch all active reservations to map vendors
            ]);

            const stallsData = stallsRes.data;
            const reservationsData = reservationsRes.data.content || reservationsRes.data;

            // Map Valid/Active Reservations to Stalls
            const stallVendorMap = {};
            reservationsData.forEach(res => {
                if (res.status === 'CONFIRMED' || res.status === 'PENDING') {
                    res.stalls.forEach(s => {
                        stallVendorMap[s.id] = res.vendor.businessName;
                    });
                }
            });

            const enrichedStalls = stallsData.map(stall => ({
                ...stall,
                vendorName: stallVendorMap[stall.id]
            }));

            setStalls(enrichedStalls);
            setLoading(false);
        } catch (err) {
            console.error("Error fetching map data:", err);
            setError("Failed to load map data.");
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchStalls();
    }, []);

    if (loading) return <AdminLayout><div className="flex justify-center items-center h-full">Loading Live Map...</div></AdminLayout>;
    if (error) return <AdminLayout><div className="text-red-500 text-center mt-10">{error}</div></AdminLayout>;

    const maxX = Math.max(...stalls.map(s => s.mapX), 0);
    const maxY = Math.max(...stalls.map(s => s.mapY), 0);

    return (
        <AdminLayout>
            <div className="mb-6">
                <h1 className="text-2xl font-bold text-gray-800">Live Stall Map</h1>
                <p className="text-gray-600">Real-time view of stall occupancy.</p>
            </div>

            <div className="overflow-auto p-8 border rounded-xl shadow-inner bg-white flex justify-center">
                <div
                    style={{
                        display: 'grid',
                        gridTemplateColumns: `repeat(${maxX + 1}, 80px)`,
                        gridTemplateRows: `repeat(${maxY + 1}, 80px)`,
                        gap: '16px',
                    }}
                >
                    {stalls.map(stall => {
                        const isReserved = stall.status === 'RESERVED';
                        let bgColor = 'bg-emerald-100 border-emerald-300 text-emerald-800';
                        if (isReserved) bgColor = 'bg-rose-100 border-rose-300 text-rose-800';

                        return (
                            <div
                                key={stall.id}
                                style={{
                                    gridColumn: stall.mapX + 1,
                                    gridRow: stall.mapY + 1
                                }}
                                className={`${bgColor} relative group border-2 rounded-lg flex flex-col items-center justify-center font-bold text-sm shadow-sm transition-all duration-200 hover:shadow-md cursor-default`}
                            >
                                <span className="text-lg">{stall.name}</span>
                                <span className="text-[10px] uppercase tracking-wide">{stall.status}</span>

                                {isReserved && stall.vendorName && (
                                    <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-1 bg-gray-900 text-white text-xs rounded shadow-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-20 pointer-events-none">
                                        Reserved by: {stall.vendorName}
                                        <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-8 border-transparent border-t-gray-900"></div>
                                    </div>
                                )}
                            </div>
                        );
                    })}
                </div>
            </div>

            <div className="mt-8 flex gap-8 justify-center">
                <div className="flex items-center gap-2">
                    <div className="w-6 h-6 bg-emerald-100 border-2 border-emerald-300 rounded"></div>
                    <span className="text-gray-700 font-medium">Available</span>
                </div>
                <div className="flex items-center gap-2">
                    <div className="w-6 h-6 bg-rose-100 border-2 border-rose-300 rounded"></div>
                    <span className="text-gray-700 font-medium">Reserved</span>
                </div>
            </div>
        </AdminLayout>
    );
};

export default AdminMap;
