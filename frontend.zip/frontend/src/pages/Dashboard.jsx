import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import StallMap from '../components/StallMap';
import BookingSummary from '../components/BookingSummary';
import api from '../services/api';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext';
import CancellationModal from '../components/common/CancellationModal';

const Dashboard = () => {
    const { user } = useAuth();
    const [selectedStalls, setSelectedStalls] = useState([]);
    const [remainingAllowance, setRemainingAllowance] = useState(3);
    const [isWarningModalOpen, setIsWarningModalOpen] = useState(false);
    const navigate = useNavigate();



    const fetchMyReservations = async () => {
        try {
            const response = await api.get('/reservations/my');
            const reservations = response.data;

            let totalBooked = 0;
            reservations.forEach(res => {
                // Assuming status is not CANCELLED, or filter if needed
                if (res.status !== 'CANCELLED') {
                    totalBooked += res.stalls.length;
                }
            });

            const allowance = Math.max(0, 3 - totalBooked);
            setRemainingAllowance(allowance);

        } catch (error) {
            console.error("Error fetching my reservations:", error);
            toast.error("Failed to load your reservations");
        }
    };

    useEffect(() => {
        fetchMyReservations();
    }, []);

    const handleSelectionChange = (newSelection) => {
        setSelectedStalls(newSelection);
    };

    const handleBookStalls = () => {
        if (selectedStalls.length === 0) {
            toast.error('Please select at least one stall');
            return;
        }
        setIsWarningModalOpen(true);
    };

    const confirmBooking = () => {
        setIsWarningModalOpen(false);
        navigate('/checkout', { state: { selectedStalls } });
    };

    return (
        <div className="w-full h-full max-w-7xl mx-auto">
            {/* Dashboard Hero Banner */}
            <div className="relative overflow-hidden bg-gradient-to-br from-indigo-50 via-blue-50 to-white rounded-3xl p-8 sm:p-10 mb-8 border border-blue-100 shadow-sm">
                <div className="absolute top-0 right-0 -mt-10 -mr-10 w-64 h-64 bg-purple-200 rounded-full mix-blend-multiply filter blur-3xl opacity-50"></div>
                <div className="absolute bottom-0 left-0 -mb-10 -ml-10 w-64 h-64 bg-blue-200 rounded-full mix-blend-multiply filter blur-3xl opacity-50"></div>

                <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                    <div>
                        <h1 className="text-4xl md:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-700 to-indigo-700 mb-2 tracking-tight">
                            Welcome back, {user?.businessName || 'Guest Vendor'}!
                        </h1>
                        <p className="text-lg text-gray-600 max-w-2xl mt-4">
                            Manage your stall reservations and view the exhibition floor plan to secure the primary spot for your business at the event.
                        </p>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Stall Map Section */}
                <div className="lg:col-span-2 relative z-50">
                    <div className="bg-white p-6 sm:p-8 rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-gray-100 transition-all duration-300 transform hover:-translate-y-1 hover:shadow-[0_8px_30px_rgb(0,0,0,0.08)] relative z-50">
                        <div className="flex items-start sm:items-center mb-8 flex-col sm:flex-row">
                            <div className="w-12 h-12 rounded-2xl bg-blue-50 flex items-center justify-center mr-5 mb-4 sm:mb-0 shrink-0 border border-blue-100">
                                <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" /></svg>
                            </div>
                            <div>
                                <h2 className="text-2xl font-bold text-gray-900 leading-tight tracking-tight">Exhibition Floor Plan</h2>
                                <p className="text-gray-500 text-sm mt-1.5 flex items-center">
                                    <span className="inline-flex items-center justify-center bg-blue-100 text-blue-800 text-xs font-bold px-2 py-0.5 rounded-full mr-2">
                                        {remainingAllowance} LEFT
                                    </span>
                                    <span>Select up to {remainingAllowance} more stall(s). Reserved spots are marked in gray.</span>
                                </p>
                            </div>
                        </div>

                        <div className="bg-gray-50 rounded-2xl p-4 sm:p-6 border border-gray-100">
                            <StallMap
                                onSelectionChange={handleSelectionChange}
                                remainingAllowance={remainingAllowance}
                            />
                        </div>
                    </div>
                </div>

                {/* Booking Summary Section */}
                <div className="lg:col-span-1 relative z-10">
                    <div className="bg-white p-6 sm:p-8 rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-gray-100 sticky top-8 transition-all duration-300 transform hover:-translate-y-1 hover:shadow-[0_8px_30px_rgb(0,0,0,0.08)] flex flex-col min-h-[400px]">
                        <div className="flex items-center mb-8">
                            <div className="w-12 h-12 rounded-2xl bg-indigo-50 flex items-center justify-center mr-4 shrink-0 border border-indigo-100">
                                <svg className="w-6 h-6 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>
                            </div>
                            <h2 className="text-2xl font-bold text-gray-900 tracking-tight">Booking Summary</h2>
                        </div>

                        <div className="mb-8 flex-1">
                            <h3 className="font-semibold text-gray-400 mb-4 text-xs uppercase tracking-widest flex items-center">
                                Selected Stalls
                                {selectedStalls.length > 0 && (
                                    <span className="ml-2 bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full text-[10px] font-bold">
                                        {selectedStalls.length}
                                    </span>
                                )}
                            </h3>

                            {selectedStalls.length > 0 ? (
                                <div className="space-y-3">
                                    {selectedStalls.map(stall => (
                                        <div key={stall.id} className="bg-white border text-gray-700 px-4 py-3 rounded-xl shadow-sm flex items-center justify-between border-indigo-100 hover:border-indigo-300 transition-colors group">
                                            <div className="flex items-center">
                                                <div className="w-2 h-2 rounded-full bg-indigo-400 mr-3 group-hover:bg-indigo-600 transition-colors"></div>
                                                <span className="font-semibold text-gray-900">{stall.name}</span>
                                            </div>
                                            <span className="text-xs font-medium text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-md">
                                                {stall.size || 'STD'}
                                            </span>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <div className="border border-dashed border-gray-200 rounded-2xl p-8 text-center bg-gray-50/50 flex flex-col items-center justify-center h-48">
                                    <svg className="w-10 h-10 text-gray-300 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" /></svg>
                                    <p className="text-gray-500 font-medium text-sm">No stalls selected yet</p>
                                    <p className="text-gray-400 text-xs mt-1 max-w-[150px]">Click on available stalls on the map to begin.</p>
                                </div>
                            )}
                        </div>

                        <div className="pt-6 mt-auto">
                            <button
                                onClick={handleBookStalls}
                                disabled={selectedStalls.length === 0}
                                className={`w-full py-4 px-6 rounded-2xl font-bold text-base transition-all duration-300 flex items-center justify-center ${selectedStalls.length > 0
                                    ? 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-lg shadow-blue-500/25 transform hover:-translate-y-0.5 focus:ring-4 focus:ring-blue-500/20'
                                    : 'bg-gray-100 text-gray-400 cursor-not-allowed border border-gray-200'
                                    }`}
                            >
                                <span>Proceed to Checkout</span>
                                {selectedStalls.length > 0 && (
                                    <svg className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
                                )}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            
            <CancellationModal 
                isOpen={isWarningModalOpen} 
                onClose={() => setIsWarningModalOpen(false)} 
                onConfirm={confirmBooking} 
            />
        </div>
    );
};

export default Dashboard;
