import React from 'react';
import Navbar from '../components/Navbar';
import SocialProof from '../components/SocialProof';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const AboutPage = () => {
    return (
        <div className="min-h-screen bg-gray-50">
            <Navbar />
            
            <div className="pt-28 pb-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                {/* Back Navigation */}
                <motion.div 
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5 }}
                >
                    <Link to="/" className="inline-flex items-center text-blue-600 hover:text-blue-800 font-medium mb-8 transition-colors group">
                        <svg className="w-5 h-5 mr-2 transform group-hover:-translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                        </svg>
                        Back to Home
                    </Link>
                </motion.div>

                {/* Main Content Area */}
                <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
                    {/* Header Section */}
                    <div className="relative bg-gradient-to-r from-blue-900 to-indigo-900 text-white py-16 px-8 text-center overlow-hidden">
                        <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
                        <motion.h1 
                            initial={{ y: 20, opacity: 0 }}
                            animate={{ y: 0, opacity: 1 }}
                            transition={{ delay: 0.2 }}
                            className="relative z-10 text-4xl md:text-5xl font-extrabold mb-4 tracking-tight"
                        >
                            The Literary Heart of <span className="text-yellow-400">Sri Lanka</span>
                        </motion.h1>
                        <p className="relative z-10 text-xl text-blue-100 max-w-2xl mx-auto">
                            Celebrating 25 years of culture, knowledge, and storytelling at the BMICH.
                        </p>
                    </div>

                    {/* Content Grid */}
                    <div className="grid md:grid-cols-2 gap-12 p-8 md:p-12 items-center">
                        <motion.div 
                            initial={{ opacity: 0, y: 30 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.6 }}
                        >
                            <h2 className="text-3xl font-bold text-gray-900 mb-6">A National Legacy</h2>
                            <p className="text-gray-600 mb-6 leading-relaxed text-lg">
                                Organized by the <span className="font-semibold text-blue-700">Sri Lanka Book Publishers' Association</span>, the Colombo International Book Fair is the premier event in our country's cultural calendar. 
                            </p>
                            <p className="text-gray-600 mb-6 leading-relaxed text-lg">
                                Every September, the historic <span className="font-semibold text-gray-800">Bandaranaike Memorial International Conference Hall (BMICH)</span> transforms into a vibrant hub for millions of book lovers, educators, and authors from around the globe.
                            </p>
                            <div className="flex items-center space-x-4 mt-8">
                                <span className="px-4 py-2 bg-blue-100 text-blue-800 rounded-full text-sm font-semibold">BMICH, Colombo 07</span>
                                <span className="px-4 py-2 bg-purple-100 text-purple-800 rounded-full text-sm font-semibold">Sep 18 - 27, 2026</span>
                            </div>
                        </motion.div>

                        <motion.div 
                            initial={{ opacity: 0, scale: 0.95 }}
                            whileInView={{ opacity: 1, scale: 1 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.6, delay: 0.2 }}
                            className="relative h-80 rounded-xl overflow-hidden shadow-lg border-4 border-white"
                        >
                             <div className="absolute inset-0 bg-gradient-to-br from-gray-200 to-gray-300 flex items-center justify-center">
                                <div className="text-center">
                                    <svg className="w-20 h-20 text-gray-400 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                                    </svg>
                                    <span className="text-gray-500 font-medium">BMICH Exhibition Centre</span>
                                </div>
                             </div>
                             <img 
                                src="https://bmkltsly13vb.compat.objectstorage.ap-singapore-1.oraclecloud.com/cdn.sg.dailymirror.lk/assets/uploads/image_65ec850bbd.jpg" 
                                alt="Books and Library" 
                                className="absolute inset-0 w-full h-full object-cover opacity-0 md:opacity-100 transition-opacity duration-700"
                                onLoad={(e) => e.target.classList.remove('opacity-0')}
                             />
                        </motion.div>
                    </div>

                    {/* Stats / Call to Action */}
                    <div className="bg-gray-50 border-t border-gray-100 p-8 md:p-12 text-center">
                        <div className="inline-block p-4 rounded-full bg-yellow-100 text-yellow-800 mb-6">
                            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
                            </svg>
                        </div>
                        <h3 className="text-2xl font-bold text-gray-900 mb-4">Reserve Your Space Today</h3>
                        <p className="text-gray-600 max-w-2xl mx-auto mb-8">
                            Join over 400 local and international publishers. Secure your stall early to ensure the best location for your readers.
                        </p>
                        <Link to="/register" className="inline-flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-full text-white bg-blue-600 hover:bg-blue-700 md:py-4 md:text-lg shadow-lg hover:shadow-xl transition-all">
                            Become an Exhibitor
                        </Link>
                    </div>
                </div>
            </div>

            <SocialProof />
        </div>
    );
};

export default AboutPage;
