import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import api from '../services/api';
import toast from 'react-hot-toast';

const GenreSelection = () => {
    const [genreInput, setGenreInput] = useState('');
    const [selectedStallId, setSelectedStallId] = useState('');
    const [genres, setGenres] = useState([]);
    const navigate = useNavigate();
    const location = useLocation();

    const reservationId = location.state?.reservationId;
    const selectedStalls = location.state?.selectedStalls || [];

    const handleAddGenre = () => {
        const trimmedGenre = genreInput.trim();

        if (trimmedGenre === '') {
            toast.error('Please enter a category/genre');
            return;
        }

        if (!selectedStallId) {
            toast.error('Please select a stall for this category');
            return;
        }

        const stall = selectedStalls.find(s => s.id.toString() === selectedStallId.toString());
        const stallName = stall ? stall.name : 'Unknown Stall';

        // Format as "StallName - Category"
        const formattedGenre = `${stallName} - ${trimmedGenre}`;

        if (genres.includes(formattedGenre)) {
            toast.error('This category has already been added to this stall');
            return;
        }

        setGenres([...genres, formattedGenre]);
        setGenreInput('');
    };

    const handleRemoveGenre = (genreToRemove) => {
        setGenres(genres.filter(genre => genre !== genreToRemove));
    };

    const handleKeyPress = (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            handleAddGenre();
        }
    };

    const handleFinish = async () => {
        if (!reservationId) {
            toast.error("No reservation found. Redirecting to dashboard.");
            navigate('/dashboard');
            return;
        }

        try {
            await api.put(`/reservations/${reservationId}/genres`, { genres });
            toast.success("Genres saved successfully!");
            navigate('/dashboard');
        } catch (error) {
            console.error("Failed to save genres", error);
            toast.error("Failed to save genres. Please try again.");
        }
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 flex items-center justify-center p-6">
            <div className="bg-white rounded-lg shadow-2xl max-w-2xl w-full p-8">

                <div className="text-center mb-8">
                    <h1 className="text-3xl font-bold text-gray-800 mb-2">
                        Add Stall Categories
                    </h1>
                    <p className="text-gray-600">
                        Assign literary genres or business categories to your reserved stalls
                    </p>
                </div>

                <div className="mb-6 bg-gray-50 p-6 rounded-xl border border-gray-100">
                    <div className="flex flex-col gap-4">
                        <div>
                            <label className="block text-gray-700 font-semibold mb-2 text-sm">
                                Select Stall:
                            </label>
                            <select
                                value={selectedStallId}
                                onChange={(e) => setSelectedStallId(e.target.value)}
                                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                            >
                                <option value="" disabled>-- Select a booked stall --</option>
                                {selectedStalls.map(stall => (
                                    <option key={stall.id} value={stall.id}>
                                        {stall.name} ({stall.size || 'Standard'})
                                    </option>
                                ))}
                                {selectedStalls.length === 0 && (
                                    <option value="" disabled>No stalls available</option>
                                )}
                            </select>
                        </div>

                        <div>
                            <label className="block text-gray-700 font-semibold mb-2 text-sm">
                                Category / Genre Name:
                            </label>
                            <div className="flex gap-2">
                                <input
                                    type="text"
                                    value={genreInput}
                                    onChange={(e) => setGenreInput(e.target.value)}
                                    onKeyPress={handleKeyPress}
                                    placeholder="e.g., Fiction, Stationery, Educational"
                                    className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
                                />
                                <button
                                    onClick={handleAddGenre}
                                    className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg transition duration-200 shadow-md whitespace-nowrap"
                                >
                                    Assign Category
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="mb-8">
                    <h3 className="text-gray-700 font-semibold mb-3 border-b pb-2">
                        Assigned Categories ({genres.length}):
                    </h3>

                    {genres.length > 0 ? (
                        <div className="bg-blue-50 rounded-lg p-4 min-h-[100px]">
                            <div className="flex flex-wrap gap-2">
                                {genres.map((genre, index) => (
                                    <div
                                        key={index}
                                        className="bg-white border border-blue-200 text-blue-800 px-4 py-2 rounded-lg font-medium flex justify-between items-center shadow-sm w-full"
                                    >
                                        <div className="flex items-center">
                                            <span className="bg-blue-100 text-blue-600 font-bold px-2 py-0.5 rounded text-xs mr-3">
                                                {genre.split(' - ')[0]}
                                            </span>
                                            <span className="text-gray-700 font-semibold">{genre.split(' - ')[1] || genre}</span>
                                        </div>
                                        <button
                                            onClick={() => handleRemoveGenre(genre)}
                                            className="text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-full w-8 h-8 flex items-center justify-center transition duration-200"
                                            title="Remove genre"
                                        >
                                            ×
                                        </button>
                                    </div>
                                ))}
                            </div>
                        </div>
                    ) : (
                        <div className="bg-gray-50 rounded-lg p-4 min-h-[100px] flex items-center justify-center">
                            <p className="text-gray-400 italic">No genres added yet</p>
                        </div>
                    )}
                </div>

                <div className="flex gap-3">
                    <button
                        onClick={() => navigate('/dashboard')}
                        className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-100 transition duration-200 font-medium"
                    >
                        Skip for Now
                    </button>
                    <button
                        onClick={handleFinish}
                        className="flex-1 px-6 py-3 bg-green-600 hover:bg-green-700 text-white font-bold rounded-lg transition duration-200 shadow-lg transform hover:-translate-y-0.5"
                    >
                        Finish
                    </button>
                </div>
            </div>
        </div>
    );
};

export default GenreSelection;
