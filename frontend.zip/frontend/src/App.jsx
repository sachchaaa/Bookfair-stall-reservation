import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { Toaster } from 'react-hot-toast';
import ProtectedRoute from './components/ProtectedRoute';

// Public Pages
import LandingPage from './pages/LandingPage';
import Login from './pages/vendor/Login';
import Register from './pages/vendor/Register';
import EmployeeLogin from './pages/EmployeeLogin';
import ForgotPassword from './pages/vendor/ForgotPassword';
import ResetPassword from './pages/ResetPassword';
import AboutPage from './pages/AboutPage';

// Vendor Pages (Protected)
import Dashboard from './pages/Dashboard';
import GenreSelection from './pages/GenreSelection';
import CheckoutPage from './pages/vendor/CheckoutPage';
import VendorLayout from './components/layout/VendorLayout';
import MyReservations from './pages/vendor/MyReservations';
import MyStallsPage from './pages/vendor/MyStallsPage';

// Employee/Admin Pages (Protected)
import AdminDashboard from './pages/AdminDashboard';
import AdminReservations from './pages/AdminReservations';
import AdminMap from './pages/admin/AdminMap';

function App() {
  return (
    <AuthProvider>
      <Toaster
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: {
            background: '#363636',
            color: '#fff',
          },
        }}
      />
      <Router>
        <Routes>
          {/* Level 0: Public Landing & Info */}
          <Route path="/" element={<LandingPage />} />
          <Route path="/about" element={<AboutPage />} />

          {/* Level 1: Authentication */}
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/employee/login" element={<EmployeeLogin />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          <Route path="/reset-password" element={<ResetPassword />} />

          {/* Level 2: Vendor Portal (Protected & Wrapped in Layout) */}
          <Route element={<VendorLayout />}>
            <Route
              path="/dashboard"
              element={
                <ProtectedRoute allowedRoles={['VENDOR']}>
                  <Dashboard />
                </ProtectedRoute>
              }
            />
            <Route
              path="/genres"
              element={
                <ProtectedRoute allowedRoles={['VENDOR']}>
                  <GenreSelection />
                </ProtectedRoute>
              }
            />
            <Route
              path="/checkout"
              element={
                <ProtectedRoute allowedRoles={['VENDOR']}>
                  <CheckoutPage />
                </ProtectedRoute>
              }
            />
            {/* Merged both pages to prevent breaking either teammate's code */}
            <Route
              path="/my-reservations"
              element={
                <ProtectedRoute allowedRoles={['VENDOR']}>
                  <MyReservations />
                </ProtectedRoute>
              }
            />
            <Route
              path="/my-stalls"
              element={
                <ProtectedRoute allowedRoles={['VENDOR']}>
                  <MyStallsPage />
                </ProtectedRoute>
              }
            />
          </Route>

          {/* Portal B: Employee Portal (Protected) */}
          <Route
            path="/admin"
            element={
              <ProtectedRoute allowedRoles={['EMPLOYEE', 'ADMIN']}>
                <AdminDashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/reservations"
            element={
              <ProtectedRoute allowedRoles={['EMPLOYEE', 'ADMIN']}>
                <AdminReservations />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/map"
            element={
              <ProtectedRoute allowedRoles={['EMPLOYEE', 'ADMIN']}>
                <AdminMap />
              </ProtectedRoute>
            }
          />

          {/* Catch-all Redirect */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;