import { useEffect } from 'react';

const BookingSummary = ({ isOpen, onClose, selectedStalls, onConfirm }) => {

    useEffect(() => {
        const handleEscape = (e) => {
            if (e.key === 'Escape' && isOpen) {
                onClose();
            }
        };
        document.addEventListener('keydown', handleEscape);
        return () => document.removeEventListener('keydown', handleEscape);
    }, [isOpen, onClose]);

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 p-4">
            <div className="bg-white rounded-lg shadow-2xl max-w-md w-full transform transition-all">

                <div className="bg-blue-600 text-white px-6 py-4 rounded-t-lg">
                    <h2 className="text-2xl font-bold">Confirm Your Reservation</h2>
                </div>

                <div className="px-6 py-6">
                    <h3 className="text-gray-700 font-semibold mb-3">Selected Stalls:</h3>

                    {selectedStalls && selectedStalls.length > 0 ? (
                        <div className="bg-blue-50 rounded-lg p-4 mb-6">
                            <div className="flex flex-wrap gap-2">
                                {selectedStalls.map((stall) => (
                                    <span
                                        key={stall.id}
                                        className="bg-blue-600 text-white px-4 py-2 rounded-full font-bold text-lg shadow-md"
                                    >
                                        {stall.name}
                                    </span>
                                ))}
                            </div>
                        </div>
                    ) : (
                        <p className="text-gray-400 italic mb-6">No stalls selected</p>
                    )}

                    <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-6">
                        <p className="text-sm text-yellow-800">
                            <strong>Note:</strong> Once confirmed, your reservation will be processed and you'll be redirected to add your literary genres.
                        </p>
                    </div>
                </div>

                <div className="px-6 py-4 bg-gray-50 rounded-b-lg flex gap-3">
                    <button
                        onClick={onClose}
                        className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-100 transition duration-200 font-medium"
                    >
                        Cancel
                    </button>
                    <button
                        onClick={onConfirm}
                        disabled={!selectedStalls || selectedStalls.length === 0}
                        className={`flex-1 px-4 py-2 rounded-lg font-bold transition duration-200 ${selectedStalls && selectedStalls.length > 0
                            ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-lg transform hover:-translate-y-0.5'
                            : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                            }`}
                    >
                        Confirm Reservation
                    </button>
                </div>
            </div>
        </div>
    );
};

export default BookingSummary;
