import React, { useState, useEffect } from 'react';
import { Link as ScrollLink } from 'react-scroll';
import { Link as RouterLink, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

const Navbar = () => {
    const [scrolled, setScrolled] = useState(false);
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
    const location = useLocation();

    const isHomePage = location.pathname === '/';

    useEffect(() => {
        const handleScroll = () => {
            const offset = window.scrollY;
            if (offset > 50) {
                setScrolled(true);
            } else {
                setScrolled(false);
            }
        };

        window.addEventListener('scroll', handleScroll);
        return () => {
            window.removeEventListener('scroll', handleScroll);
        };
    }, []);

    const navLinks = [
        { name: 'Pricing', to: 'pricing' },
        { name: 'Map', to: 'map' },
    ];

    return (
        <nav
            className={`fixed w-full z-50 transition-all duration-300 ${scrolled
                ? 'bg-white/30 backdrop-blur-md shadow-lg border-b border-white/20 py-2'
                : 'bg-transparent py-4'
                }`}
        >
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between items-center">
                    {/* Logo */}
                    <RouterLink to="/" className="flex items-center gap-2 group">
                        <span className={`text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-600 transition-all duration-300 ${scrolled ? 'scale-100' : 'scale-110'}`}>
                            BookFair
                        </span>
                    </RouterLink>

                    {/* Desktop Navigation */}
                    <div className="hidden md:flex items-center space-x-8">
                        {/* About is always a Route */}
                        <RouterLink
                            to="/about"
                            className="text-gray-700 hover:text-blue-600 font-medium cursor-pointer transition-colors relative group"
                        >
                            About
                            <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-blue-600 transition-all group-hover:w-full"></span>
                        </RouterLink>

                        {/* Other links handled conditionally */}
                        {isHomePage ? (
                            navLinks.filter(link => link.name !== 'About').map((link) => (
                                <ScrollLink
                                    key={link.name}
                                    to={link.to}
                                    smooth={true}
                                    duration={500}
                                    offset={-70}
                                    className="text-gray-700 hover:text-blue-600 font-medium cursor-pointer transition-colors relative group"
                                >
                                    {link.name}
                                    <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-blue-600 transition-all group-hover:w-full"></span>
                                </ScrollLink>
                            ))
                        ) : (
                            navLinks.filter(link => link.name !== 'About').map((link) => (
                                <RouterLink
                                    key={link.name}
                                    to={`/#${link.to}`}
                                    className="text-gray-700 hover:text-blue-600 font-medium cursor-pointer transition-colors relative group"
                                >
                                    {link.name}
                                    <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-blue-600 transition-all group-hover:w-full"></span>
                                </RouterLink>
                            ))
                        )}

                        <RouterLink
                            to="/login"
                            className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-2 rounded-full font-medium hover:shadow-lg hover:scale-105 transition-all duration-300"
                        >
                            Vendor Login
                        </RouterLink>
                    </div>

                    {/* Mobile Menu Button */}
                    <div className="md:hidden flex items-center">
                        <button
                            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                            className="text-gray-700 hover:text-blue-600 focus:outline-none"
                        >
                            <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                {mobileMenuOpen ? (
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                ) : (
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                                )}
                            </svg>
                        </button>
                    </div>
                </div>
            </div>

            {/* Mobile Menu */}
            <AnimatePresence>
                {mobileMenuOpen && (
                    <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="md:hidden bg-white/95 backdrop-blur-xl border-t border-gray-100 overflow-hidden"
                    >
                        <div className="px-4 pt-2 pb-6 space-y-2 flex flex-col items-center">
                            <RouterLink
                                to="/about"
                                onClick={() => setMobileMenuOpen(false)}
                                className="block w-full text-center px-3 py-2 text-gray-700 hover:text-blue-600 font-medium hover:bg-gray-50 rounded-md cursor-pointer"
                            >
                                About
                            </RouterLink>

                            {isHomePage ? (
                                navLinks.filter(link => link.name !== 'About').map((link) => (
                                    <ScrollLink
                                        key={link.name}
                                        to={link.to}
                                        smooth={true}
                                        duration={500}
                                        offset={-70}
                                        onClick={() => setMobileMenuOpen(false)}
                                        className="block w-full text-center px-3 py-2 text-gray-700 hover:text-blue-600 font-medium hover:bg-gray-50 rounded-md cursor-pointer"
                                    >
                                        {link.name}
                                    </ScrollLink>
                                ))
                            ) : (
                                navLinks.filter(link => link.name !== 'About').map((link) => (
                                    <RouterLink
                                        key={link.name}
                                        to={`/#${link.to}`}
                                        onClick={() => setMobileMenuOpen(false)}
                                        className="block w-full text-center px-3 py-2 text-gray-700 hover:text-blue-600 font-medium hover:bg-gray-50 rounded-md cursor-pointer"
                                    >
                                        {link.name}
                                    </RouterLink>
                                ))
                            )}
                            <RouterLink
                                to="/login"
                                onClick={() => setMobileMenuOpen(false)}
                                className="block w-full text-center mt-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-2.5 rounded-full font-medium shadow-md"
                            >
                                Vendor Login
                            </RouterLink>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </nav>
    );
};

export default Navbar;
