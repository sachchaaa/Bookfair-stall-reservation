import { useState, useEffect } from 'react';
import api from '../services/api';

const ReservationTicket = ({ reservationId }) => {
    const [qrUrl, setQrUrl] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    useEffect(() => {
        let objectUrl; 

        const fetchQr = async () => {
            try {
                
                const response = await api.get(`/reservations/${reservationId}/qr`, {
                    responseType: 'blob'
                });
                
                
                objectUrl = URL.createObjectURL(response.data);
                setQrUrl(objectUrl);
            } catch {
                setError('Failed to load QR code. It may not exist yet.');
            } finally {
                setLoading(false);
            }
        };

        if (reservationId) {
            fetchQr();
        }

        
        return () => {
            if (objectUrl) URL.revokeObjectURL(objectUrl);
        };
    }, [reservationId]);

    if (loading) {
        return (
            <div className="flex justify-center items-center h-48 bg-gray-100 rounded-lg animate-pulse">
                <p className="text-gray-500 font-medium">Generating Ticket...</p>
            </div>
        );
    }

    if (error) return <p className="text-red-500 text-center font-medium p-4">{error}</p>;

    return (
        <div className="flex flex-col items-center p-6 border-2 border-dashed border-gray-300 rounded-xl bg-white">
            <h3 className="text-xl font-bold mb-4 text-gray-800">Official Entrance Pass</h3>
            {qrUrl && (
                <div className="flex flex-col items-center gap-4">
                    <img 
                        src={qrUrl} 
                        alt="Reservation QR Code" 
                        className="w-48 h-48 object-contain shadow-sm border p-2 rounded"
                    />
                    <a 
                        href={qrUrl} 
                        download={`reservation-${reservationId}.png`}
                        className="text-sm bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold py-2 px-4 rounded inline-flex items-center transition"
                    >
                        <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path>
                        </svg>
                        Download Ticket
                    </a>
                </div>
            )}
            <p className="text-sm text-gray-500 mt-4 font-mono">Res ID: #{reservationId}</p>
        </div>
    );
};

export default ReservationTicket;
