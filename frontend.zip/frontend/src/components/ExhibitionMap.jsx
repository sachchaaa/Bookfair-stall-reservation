import React, { useState, useEffect } from 'react';
import api from '../services/api';

const ExhibitionMap = () => {
    const [stalls, setStalls] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [hoveredStall, setHoveredStall] = useState(null);
    const [tooltipPos, setTooltipPos] = useState({ x: 0, y: 0 });

    const handleMouseMove = (e) => {
        setTooltipPos({ x: e.clientX, y: e.clientY });
    };

    useEffect(() => {
        const fetchStalls = async () => {
            try {
                const response = await api.get('/stalls');
                setStalls(response.data);
                setLoading(false);
            } catch (err) {
                console.error("Error fetching stalls:", err);
                // Fallback to mock data for demo purposes if backend is unreachable
                setStalls([
                    { id: 1, name: 'A1', mapX: 0, mapY: 0, status: 'AVAILABLE', size: 'LARGE', price: 15000 },
                    { id: 2, name: 'A2', mapX: 1, mapY: 0, status: 'RESERVED', size: 'LARGE', price: 15000 },
                    { id: 3, name: 'A3', mapX: 2, mapY: 0, status: 'AVAILABLE', size: 'LARGE', price: 15000 },
                    { id: 4, name: 'B1', mapX: 0, mapY: 1, status: 'AVAILABLE', size: 'MEDIUM', price: 10000 },
                    { id: 5, name: 'B2', mapX: 1, mapY: 1, status: 'AVAILABLE', size: 'MEDIUM', price: 10000 },
                    { id: 6, name: 'B3', mapX: 2, mapY: 1, status: 'AVAILABLE', size: 'MEDIUM', price: 10000 },
                    { id: 7, name: 'C1', mapX: 0, mapY: 2, status: 'AVAILABLE', size: 'SMALL', price: 5000 },
                    { id: 8, name: 'C2', mapX: 1, mapY: 2, status: 'AVAILABLE', size: 'SMALL', price: 5000 },
                    { id: 9, name: 'C3', mapX: 2, mapY: 2, status: 'RESERVED', size: 'SMALL', price: 5000 },
                ]);
                setError(null);
                setLoading(false);
            }
        };

        fetchStalls();
    }, []);

    if (loading) return <div className="h-64 flex items-center justify-center text-gray-500">Loading Map...</div>;
    if (error) return <div className="h-64 flex items-center justify-center text-red-500">{error}</div>;

    // Determine grid dimensions
    const maxX = Math.max(...stalls.map(s => s.mapX), 0);
    const maxY = Math.max(...stalls.map(s => s.mapY), 0);

    const stallWidth = 60;
    const stallHeight = 60;
    const gap = 10;
    const viewBoxWidth = (maxX + 1) * (stallWidth + gap) + gap;
    const viewBoxHeight = (maxY + 1) * (stallHeight + gap) + gap;

    return (
        <div className="relative w-full overflow-hidden rounded-lg shadow-lg bg-gray-50 border border-gray-200">
            <div className="overflow-auto text-center p-8">
                <svg
                    viewBox={`0 0 ${viewBoxWidth} ${viewBoxHeight}`}
                    className="mx-auto"
                    style={{ maxHeight: '500px', maxWidth: '100%' }}
                >
                    {stalls.map(stall => {
                        const x = stall.mapX * (stallWidth + gap) + gap;
                        const y = stall.mapY * (stallHeight + gap) + gap;
                        const isReserved = stall.status === 'RESERVED';
                        const fillColor = isReserved ? '#9CA3AF' : '#10B981'; // Gray-400 : Emerald-500
                        const strokeColor = isReserved ? '#6B7280' : '#059669'; // Gray-500 : Emerald-600

                        return (
                            <g
                                key={stall.id}
                                onMouseEnter={() => setHoveredStall(stall)}
                                onMouseMove={handleMouseMove}
                                onMouseLeave={() => setHoveredStall(null)}
                                className="cursor-pointer transition-opacity hover:opacity-80"
                            >
                                <rect
                                    x={x}
                                    y={y}
                                    width={stallWidth}
                                    height={stallHeight}
                                    rx="4"
                                    fill={fillColor}
                                    stroke={strokeColor}
                                    strokeWidth="2"
                                />
                                <text
                                    x={x + stallWidth / 2}
                                    y={y + stallHeight / 2}
                                    textAnchor="middle"
                                    dominantBaseline="middle"
                                    fill="white"
                                    fontSize="14"
                                    fontWeight="bold"
                                    pointerEvents="none"
                                >
                                    {stall.name}
                                </text>
                            </g>
                        );
                    })}
                </svg>
            </div>

            {/* Tooltip */}
            {/* Tooltip */}
            {hoveredStall && (
                <div
                    className="fixed z-50 p-4 bg-white/95 backdrop-blur-sm rounded-xl shadow-2xl border border-gray-100 text-left pointer-events-none transition-all duration-75 ease-out"
                    style={{
                        left: tooltipPos.x + 20,
                        top: tooltipPos.y + 20,
                        minWidth: '200px'
                    }}
                >
                    <div className="flex justify-between items-start mb-2">
                        <h3 className="font-bold text-xl text-gray-800">{hoveredStall.name}</h3>
                        <span className={`px-2 py-1 rounded text-xs font-bold uppercase tracking-wide
                            ${hoveredStall.status === 'RESERVED' ? 'bg-red-100 text-red-600' : 'bg-emerald-100 text-emerald-600'}`}>
                            {hoveredStall.status}
                        </span>
                    </div>
                    
                    <div className="space-y-2 text-sm">
                        <div className="flex justify-between items-center py-1 border-b border-gray-100">
                            <span className="text-gray-500">Size</span>
                            <span className="font-semibold text-gray-700">{hoveredStall.size || 'Standard'}</span>
                        </div>
                        <div className="flex justify-between items-center py-1">
                            <span className="text-gray-500">Price</span>
                            <span className="font-bold text-lg text-indigo-600">
                                {new Intl.NumberFormat('en-LK', { style: 'currency', currency: 'LKR' }).format(hoveredStall.price || 0)}
                            </span>
                        </div>
                    </div>
                </div>
            )}

            {/* Legend */}
            <div className="bg-white p-4 border-t border-gray-200 flex justify-center gap-6 text-sm">
                <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded bg-emerald-500"></div>
                    <span className="text-gray-700">Available</span>
                </div>
                <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded bg-gray-400"></div>
                    <span className="text-gray-700">Reserved</span>
                </div>
            </div>
        </div>
    );
};

export default ExhibitionMap;
