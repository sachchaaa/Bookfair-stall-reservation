import React, { useState } from 'react';
import toast from 'react-hot-toast';

const ReservationTable = () => {
  // Mock data - replace with API call
  const [reservations, setReservations] = useState([
    { id: 1, vendorName: 'Book Worms', stallName: 'A1', size: 'Small', date: '2023-10-01', status: 'ACTIVE' },
    { id: 2, vendorName: 'Literature Hub', stallName: 'B2', size: 'Medium', date: '2023-10-02', status: 'ACTIVE' },
    { id: 3, vendorName: 'Knowledge Press', stallName: 'C3', size: 'Large', date: '2023-10-03', status: 'CANCELLED' },
  ]);

  const [filters, setFilters] = useState({
    date: '',
    size: '',
    vendor: ''
  });

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleCancel = (id) => {
    toast((t) => (
      <div className="flex flex-col gap-2">
        <span className="font-semibold text-gray-800">Are you sure you want to cancel this reservation?</span>
        <div className="flex gap-2 justify-end">
          <button
            className="bg-red-500 text-white px-3 py-1 rounded text-sm hover:bg-red-600 transition"
            onClick={() => {
              toast.dismiss(t.id);
              // API call to cancel reservation would go here
              setReservations(prev => prev.map(res => 
                res.id === id ? { ...res, status: 'CANCELLED' } : res
              ));
              toast.success(`Reservation ${id} cancelled`);
            }}
          >
            Yes, Cancel
          </button>
          <button
            className="bg-gray-200 px-3 py-1 rounded text-sm hover:bg-gray-300 transition text-gray-800"
            onClick={() => toast.dismiss(t.id)}
          >
            Dismiss
          </button>
        </div>
      </div>
    ), { duration: 5000, position: 'top-center', style: { border: '1px solid #e5e7eb' } });
  };

  const filteredReservations = reservations.filter(res => {
    return (
      (filters.date === '' || res.date === filters.date) &&
      (filters.size === '' || res.size === filters.size) &&
      (filters.vendor === '' || res.vendorName.toLowerCase().includes(filters.vendor.toLowerCase()))
    );
  });

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-4 text-gray-800">Reservation Management</h2>
      
      {/* Filters */}
      <div className="flex flex-wrap gap-4 mb-6">
        <div className="flex-1 min-w-[200px]">
          <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
          <input
            type="date"
            name="date"
            value={filters.date}
            onChange={handleFilterChange}
            className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
        
        <div className="flex-1 min-w-[200px]">
          <label className="block text-sm font-medium text-gray-700 mb-1">Stall Size</label>
          <select
            name="size"
            value={filters.size}
            onChange={handleFilterChange}
            className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">All Sizes</option>
            <option value="Small">Small</option>
            <option value="Medium">Medium</option>
            <option value="Large">Large</option>
          </select>
        </div>
        
        <div className="flex-1 min-w-[200px]">
          <label className="block text-sm font-medium text-gray-700 mb-1">Vendor Name</label>
          <input
            type="text"
            name="vendor"
            placeholder="Search vendor..."
            value={filters.vendor}
            onChange={handleFilterChange}
            className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Vendor</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stall</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Size</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredReservations.length > 0 ? (
              filteredReservations.map((res) => (
                <tr key={res.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{res.id}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{res.vendorName}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{res.stallName}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{res.size}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{res.date}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      res.status === 'ACTIVE' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {res.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    {res.status === 'ACTIVE' && (
                      <button
                        onClick={() => handleCancel(res.id)}
                        className="text-red-600 hover:text-red-900 font-medium"
                      >
                        Cancel
                      </button>
                    )}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="7" className="px-6 py-4 text-center text-sm text-gray-500">
                  No reservations found matching criteria.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ReservationTable;