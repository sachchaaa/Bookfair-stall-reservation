import React, { useState } from 'react';

const AvailabilityChecker = () => {
    const [selectedSize, setSelectedSize] = useState('Large');

    // Mock data for stalls - to be replaced with API call
    const allStalls = [
        { id: 'A1', size: 'Small', status: 'AVAILABLE' },
        { id: 'A2', size: 'Small', status: 'RESERVED' },
        { id: 'B1', size: 'Medium', status: 'AVAILABLE' },
        { id: 'B2', size: 'Medium', status: 'AVAILABLE' },
        { id: 'C1', size: 'Large', status: 'RESERVED' },
        { id: 'C2', size: 'Large', status: 'AVAILABLE' },
        { id: 'C3', size: 'Large', status: 'AVAILABLE' },
    ];

    const availableStalls = allStalls.filter(
        stall => stall.size === selectedSize && stall.status === 'AVAILABLE'
    );

    return (
        <div className="bg-white p-6 rounded-lg shadow-md mt-8">
            <h2 className="text-xl font-semibold mb-4 text-gray-800">Availability Checker</h2>

            <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">Select Stall Size:</label>
                <div className="flex space-x-4">
                    {['Small', 'Medium', 'Large'].map((size) => (
                        <button
                            key={size}
                            onClick={() => setSelectedSize(size)}
                            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${selectedSize === size
                                    ? 'bg-blue-600 text-white'
                                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                                }`}
                        >
                            {size}
                        </button>
                    ))}
                </div>
            </div>

            <div className="bg-gray-50 p-4 rounded-md border border-gray-200">
                <h3 className="text-md font-medium text-gray-700 mb-3">
                    Available {selectedSize} Stalls ({availableStalls.length})
                </h3>

                {availableStalls.length > 0 ? (
                    <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-3">
                        {availableStalls.map((stall) => (
                            <div
                                key={stall.id}
                                className="bg-green-100 text-green-800 py-2 px-3 rounded text-center text-sm font-bold border border-green-200"
                            >
                                {stall.id}
                            </div>
                        ))}
                    </div>
                ) : (
                    <p className="text-gray-500 italic">No {selectedSize} stalls available.</p>
                )}
            </div>
        </div>
    );
};

export default AvailabilityChecker;