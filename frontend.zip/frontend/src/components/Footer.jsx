import React from 'react';
import { Link as RouterLink, useLocation } from 'react-router-dom';
import { Link as ScrollLink } from 'react-scroll';
import { Facebook, Twitter, Instagram, Mail, ArrowUp } from 'lucide-react';

const Footer = () => {
    const location = useLocation();
    const isHomePage = location.pathname === '/';

    const renderScrollLink = (to, name) => {
        if (isHomePage) {
            return (
                <ScrollLink
                    to={to}
                    smooth={true}
                    duration={500}
                    offset={-70}
                    className="text-gray-400 hover:text-white transition-colors cursor-pointer"
                >
                    {name}
                </ScrollLink>
            );
        } else {
            return (
                <RouterLink
                    to={`/#${to}`}
                    className="text-gray-400 hover:text-white transition-colors cursor-pointer"
                >
                    {name}
                </RouterLink>
            );
        }
    };

    return (
        <footer className="bg-gray-900 text-white pt-16 pb-8 border-t border-gray-800">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">

                    {/* Brand Column */}
                    <div className="space-y-4">
                        <RouterLink to="/" className="flex items-center gap-2 group">
                            <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-indigo-400">
                                BookFair
                            </span>
                        </RouterLink>
                        <p className="text-gray-400 text-sm leading-relaxed">
                            The premier literary event of the year, connecting readers, authors, and publishers in the heart of Colombo.
                        </p>
                        <p className="text-xs text-gray-500">
                            &copy; 2026 Colombo International Book Fair. <br /> All rights reserved.
                        </p>
                    </div>

                    {/* Quick Links */}
                    <div>
                        <h3 className="text-lg font-semibold mb-4 text-white">Quick Links</h3>
                        <ul className="space-y-2">
                            <li>
                                {isHomePage ? (
                                    <button
                                        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                                        className="text-gray-400 hover:text-white transition-colors cursor-pointer flex items-center gap-1"
                                    >
                                        Home <ArrowUp size={14} />
                                    </button>
                                ) : (
                                    <RouterLink to="/" className="text-gray-400 hover:text-white transition-colors">
                                        Home
                                    </RouterLink>
                                )}
                            </li>
                            <li>{renderScrollLink('overview', 'About Event')}</li>
                            <li>{renderScrollLink('pricing', 'Stall Pricing')}</li>
                            <li>{renderScrollLink('map', 'Exhibition Map')}</li>
                        </ul>
                    </div>

                    {/* Resources */}
                    <div>
                        <h3 className="text-lg font-semibold mb-4 text-white">Resources</h3>
                        <ul className="space-y-2">
                            <li>
                                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                                    Vendor Guidelines
                                </a>
                            </li>
                            <li>
                                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                                    Download Floor Plan (PDF)
                                </a>
                            </li>
                            <li>
                                <RouterLink to="/employee/login" className="text-gray-400 hover:text-white transition-colors">
                                    Employee Portal
                                </RouterLink>
                            </li>
                        </ul>
                    </div>

                    {/* Connect */}
                    <div>
                        <h3 className="text-lg font-semibold mb-4 text-white">Stay Connected</h3>
                        <div className="flex gap-4 mb-6">
                            <a href="#" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center text-gray-400 hover:bg-blue-600 hover:text-white transition-all">
                                <Facebook size={20} />
                            </a>
                            <a href="#" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center text-gray-400 hover:bg-sky-500 hover:text-white transition-all">
                                <Twitter size={20} />
                            </a>
                            <a href="#" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center text-gray-400 hover:bg-pink-600 hover:text-white transition-all">
                                <Instagram size={20} />
                            </a>
                        </div>

                        <div className="relative">
                            <input
                                type="email"
                                placeholder="Subscribe to newsletter"
                                className="w-full bg-gray-800 text-white text-sm rounded-lg pl-4 pr-12 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 border border-gray-700 placeholder-gray-500"
                            />
                            <button className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white">
                                <Mail size={18} />
                            </button>
                        </div>
                    </div>
                </div>

                <div className="border-t border-gray-800 pt-8 text-center md:text-left flex flex-col md:flex-row justify-between items-center text-xs text-gray-500">
                    <p>Designed for better reading experiences.</p>
                    <div className="flex gap-6 mt-4 md:mt-0">
                        <a href="#" className="hover:text-white">Privacy Policy</a>
                        <a href="#" className="hover:text-white">Terms of Service</a>
                    </div>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
