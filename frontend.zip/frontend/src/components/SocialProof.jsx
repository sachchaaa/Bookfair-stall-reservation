import React from 'react';

const testimonials = [
  {
    id: 1,
    name: "Priyantha Perera",
    role: "Avid Reader",
    content: "The Colombo International Book Fair is my favorite event of the year. This system makes it so easy to plan my visit!",
    avatar: "https://img.freepik.com/premium-vector/male-face-avatar-icon-set-flat-design-social-media-profiles_1281173-3806.jpg?semt=ais_user_personalization&w=740&q=80"
  },
  {
    id: 2,
    name: "Sanduni Jayasuriya",
    role: "Publisher",
    content: "As a vendor, the stall reservation process has never been smoother. A great initiative for the local literature scene.",
    avatar: "https://img.freepik.com/free-vector/woman-with-long-dark-hair_1308-176666.jpg?semt=ais_user_personalization&w=740&q=80"
  },
  {
    id: 3,
    name: "Michael De Silva",
    role: "Exhibitor",
    content: "Efficient, transparent, and user-friendly. Highly recommended for anyone involved in the book fair.",
    avatar: "https://img.freepik.com/premium-vector/man-avatar-profile-picture-isolated-background-avatar-profile-picture-man_1293239-4841.jpg"
  }
];

const stats = [
  { label: "Books Available", value: "50,000+" },
  { label: "Registered Vendors", value: "200+" },
  { label: "Years of Tradition", value: "10+" },
  { label: "Daily Visitors", value: "5,000+" }
];

const SocialProof = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Trusted by Thousands of Book Lovers
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Join the community of readers, publishers, and educators who make the Sri Lanka Book Fair a resounding success every year.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-20 text-center">
          {stats.map((stat, index) => (
            <div key={index} className="p-6 bg-white rounded-xl shadow-sm border border-gray-100 transition-transform hover:scale-105">
              <div className="text-3xl font-bold text-primary-600 mb-2">{stat.value}</div>
              <div className="text-sm font-medium text-gray-500 uppercase tracking-wider">{stat.label}</div>
            </div>
          ))}
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <div key={testimonial.id} className="bg-white p-8 rounded-2xl shadow-md border border-gray-50 relative">
              <div className="flex items-center mb-6">
                <img
                  src={testimonial.avatar}
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full mr-4 bg-gray-100"
                />
                <div>
                  <h4 className="font-bold text-gray-900">{testimonial.name}</h4>
                  <p className="text-sm text-gray-500">{testimonial.role}</p>
                </div>
              </div>
              <p className="text-gray-600 italic leading-relaxed">
                "{testimonial.content}"
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SocialProof;
