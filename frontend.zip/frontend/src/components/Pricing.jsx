import React from 'react';
import { Link } from 'react-router-dom';

const Pricing = () => {
    const plans = [
        {
            name: 'Small Stall',
            price: 'Rs. 5,000',
            features: ['3x3 meters', 'Basic Lighting', '1 Table, 2 Chairs', 'Standard Wifi'],
            isPopular: false,
        },
        {
            name: 'Medium Stall',
            price: 'Rs. 10,000',
            features: ['5x5 meters', 'Premium Lighting', '2 Tables, 4 Chairs', 'High-speed Wifi', 'Prime Location'],
            isPopular: true,
        },
        {
            name: 'Large Stall',
            price: 'Rs. 15,000',
            features: ['8x8 meters', 'Full Customization', '4 Tables, 8 Chairs', 'Dedicated Fiber Wifi', 'Corner Location'],
            isPopular: false,
        },
    ];

    return (
        <section id="pricing" className="py-20 bg-gray-50">
            <div className="container mx-auto px-4">
                <div className="text-center mb-16">
                    <h2 className="text-4xl font-bold text-gray-900 mb-4">Choose Your Stall Space</h2>
                    <p className="text-xl text-gray-600">Premium locations for maximum visitor engagement</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
                    {plans.map((plan, index) => (
                        <div
                            key={index}
                            className={`relative flex flex-col p-8 bg-white rounded-2xl transition-all duration-300 transform hover:-translate-y-2 hover:shadow-xl ${plan.isPopular
                                ? 'border-2 border-blue-500 shadow-lg scale-105 z-10'
                                : 'border border-gray-200'
                                }`}
                        >
                            {plan.isPopular && (
                                <div className="absolute top-0 right-0 transform translate-x-2 -translate-y-2">
                                    <span className="bg-blue-500 text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider shadow-md">
                                        Popular
                                    </span>
                                </div>
                            )}

                            <div className="mb-8">
                                <h3 className="text-2xl font-bold text-gray-900 mb-4">{plan.name}</h3>
                                <div className="flex items-baseline">
                                    <span className="text-4xl font-extrabold text-gray-900">{plan.price}</span>
                                    <span className="text-gray-500 ml-1">/event</span>
                                </div>
                            </div>

                            <ul className="flex-1 mb-8 space-y-4">
                                {plan.features.map((feature, idx) => (
                                    <li key={idx} className="flex items-center text-gray-600">
                                        <svg className="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                                        </svg>
                                        {feature}
                                    </li>
                                ))}
                            </ul>

                            <Link
                                to="/register"
                                className={`w-full py-3 px-6 rounded-xl font-bold text-center transition-colors duration-200 ${plan.isPopular
                                    ? 'bg-blue-600 text-white hover:bg-blue-700'
                                    : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                                    }`}
                            >
                                Get Started
                            </Link>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Pricing;