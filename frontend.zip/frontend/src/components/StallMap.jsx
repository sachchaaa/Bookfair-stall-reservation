import { useState, useEffect } from 'react';
import api from '../services/api';
import toast from 'react-hot-toast';

const StallMap = ({ onSelectionChange, remainingAllowance = 3 }) => {
    const [stalls, setStalls] = useState([]);
    const [selectedStalls, setSelectedStalls] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        // Reset selection if allowance changes to be less than current selection
        if (selectedStalls.length > remainingAllowance) {
            const trimmedSelection = selectedStalls.slice(0, remainingAllowance);
            setSelectedStalls(trimmedSelection);
            onSelectionChange(trimmedSelection);
        }
    }, [remainingAllowance, selectedStalls, onSelectionChange]);

    const fetchStalls = async () => {
        try {
            const response = await api.get('/stalls');
            setStalls(response.data);
            setLoading(false);
        } catch (err) {
            console.error("Error fetching stalls:", err);

            setStalls([
                { id: 1, name: 'A1', mapX: 0, mapY: 0, status: 'AVAILABLE' },
                { id: 2, name: 'A2', mapX: 1, mapY: 0, status: 'RESERVED' },
                { id: 3, name: 'A3', mapX: 2, mapY: 0, status: 'AVAILABLE' },
                { id: 4, name: 'B1', mapX: 0, mapY: 1, status: 'AVAILABLE' },
                { id: 5, name: 'B2', mapX: 1, mapY: 1, status: 'AVAILABLE' },
                { id: 6, name: 'B3', mapX: 2, mapY: 1, status: 'AVAILABLE' },
                { id: 7, name: 'C1', mapX: 0, mapY: 2, status: 'AVAILABLE' },
                { id: 8, name: 'C2', mapX: 1, mapY: 2, status: 'AVAILABLE' },
                { id: 9, name: 'C3', mapX: 2, mapY: 2, status: 'RESERVED' },
            ]);
            setLoading(false);
            setError(null);
        }
    };

    useEffect(() => {
        fetchStalls();
    }, []);

    const toggleSelection = (stall) => {
        if (stall.status === 'RESERVED') return;

        const isSelected = selectedStalls.some(s => s.id === stall.id);

        if (isSelected) {
            const newSelection = selectedStalls.filter(s => s.id !== stall.id);
            setSelectedStalls(newSelection);
            onSelectionChange(newSelection);
        } else {
            if (selectedStalls.length >= remainingAllowance) {
                toast.error(`You can only select up to ${remainingAllowance} more stall(s). Total limit is 3.`);
                return;
            }

            const newSelection = [...selectedStalls, stall];
            setSelectedStalls(newSelection);
            onSelectionChange(newSelection);
        }
    };

    if (loading) {
        return (
            <div className="overflow-auto p-8 border rounded-2xl shadow-inner bg-gray-50 flex flex-col items-center justify-center min-h-[350px]">
                <div className="animate-pulse flex flex-wrap justify-center gap-3 max-w-2xl">
                    {[...Array(24)].map((_, i) => (
                        <div key={i} className="w-[60px] h-[60px] bg-gray-200 rounded-lg shadow-sm"></div>
                    ))}
                </div>
                <div className="mt-8 flex items-center gap-3">
                    <div className="w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                    <span className="text-gray-500 font-semibold tracking-wide">Loading exhibition map...</span>
                </div>
            </div>
        );
    }
    
    if (error) return <div className="text-center p-4 text-red-500 bg-red-50 rounded-lg">{error}</div>;

    const maxX = Math.max(...stalls.map(s => s.mapX), 0);
    const maxY = Math.max(...stalls.map(s => s.mapY), 0);

    return (
        <div className="p-8 lg:p-12 border rounded-2xl shadow-inner bg-gray-50 flex flex-col items-center justify-center w-full overflow-x-auto">
            
            {/* Map Grid Container */}
            <div
                className="w-max"
                style={{
                    display: 'grid',
                    gridTemplateColumns: `repeat(${maxX + 1}, 60px)`,
                    gridTemplateRows: `repeat(${maxY + 1}, 60px)`,
                    gap: '10px',
                    justifyContent: 'center'
                }}
            >
                {stalls.map(stall => {
                    const isSelected = selectedStalls.some(s => s.id === stall.id);
                    const isReserved = stall.status === 'RESERVED';

                    let bgColor = 'bg-white';
                    if (isReserved) bgColor = 'bg-gray-400 cursor-not-allowed';
                    else if (isSelected) bgColor = 'bg-blue-500 text-white';
                    else bgColor = 'bg-green-100 hover:bg-green-200 cursor-pointer';

                    // Abbreviate the size for the inner text
                    let sizeAbbr = 'S';
                    if (stall.size === 'MEDIUM') sizeAbbr = 'M';
                    else if (stall.size === 'LARGE') sizeAbbr = 'L';
                    
                    // Format the full size for the tooltip
                    let fullSize = 'Small';
                    if (stall.size === 'MEDIUM') fullSize = 'Medium';
                    else if (stall.size === 'LARGE') fullSize = 'Large';

                    // Fallback price logic if not directly in the stall object
                    const stallPrice = stall.price || (stall.size === 'SMALL' ? 5000 : stall.size === 'MEDIUM' ? 10000 : 15000);

                    // --- Tooltip Dynamic Positioning ---
                    const isTopRow = stall.mapY <= 1; // Top two rows show tooltip below
                    const tooltipYClass = isTopRow ? 'top-full mt-2.5' : 'bottom-full mb-2.5';
                    
                    let tooltipXClass = 'left-1/2 -translate-x-1/2';
                    let arrowXClass = 'left-1/2 -translate-x-1/2';

                    if (stall.mapX === 0) {
                        tooltipXClass = 'left-0';
                        arrowXClass = 'left-[24px]'; // Positioned at 24px (middle of the 60px stall)
                    } else if (stall.mapX === maxX) {
                        tooltipXClass = 'right-0';
                        arrowXClass = 'right-[24px]';
                    }

                    const headerBgClass = isReserved ? 'bg-gray-500' : isSelected ? 'bg-blue-600' : 'bg-green-500';
                    const arrowYClass = isTopRow ? '-top-1.5' : '-bottom-1.5';
                    // The arrow's background color matches the header if it points UP, or the white body if it points DOWN
                    const arrowBgClass = isTopRow ? headerBgClass : 'bg-white border-b border-r border-gray-100';

                    return (
                        <div
                            key={stall.id}
                            onClick={() => toggleSelection(stall)}
                            style={{
                                gridColumn: stall.mapX + 1,
                                gridRow: stall.mapY + 1
                            }}
                            className={`${bgColor} border border-gray-300 rounded flex flex-col items-center justify-center font-bold text-sm shadow-sm transition-all duration-200 relative group hover:z-[100] hover:scale-105`}
                        >
                            <span>{stall.name}</span>
                            <span className="text-[10px] opacity-75 font-medium">{sizeAbbr}</span>
                            
                            {/* Detailed Custom Tooltip */}
                            <div className={`absolute ${tooltipYClass} ${tooltipXClass} w-48 bg-white text-gray-800 text-xs rounded-xl shadow-[0_10px_40px_rgba(0,0,0,0.15)] border border-gray-100 opacity-0 pointer-events-none group-hover:opacity-100 transition-all duration-300 flex flex-col z-[110]`}>
                                <div className={`p-2 font-bold text-white text-center rounded-t-xl ${headerBgClass} relative z-[111]`}>
                                    Stall {stall.name}
                                </div>
                                <div className="p-3 space-y-2 flex flex-col bg-white rounded-b-xl relative z-[111]">
                                    <div className="flex justify-between items-center"><span className="text-gray-500 font-semibold">Status:</span> <span className={`font-bold ${isReserved ? 'text-gray-600' : isSelected ? 'text-blue-600' : 'text-green-600'}`}>{stall.status}</span></div>
                                    <div className="flex justify-between items-center"><span className="text-gray-500 font-semibold">Size:</span> <span className="font-bold">{fullSize}</span></div>
                                    <div className="flex justify-between items-center"><span className="text-gray-500 font-semibold">Price:</span> <span className="font-bold text-gray-900">Rs {stallPrice.toLocaleString()}</span></div>
                                </div>
                                
                                {/* Tooltip Arrow */}
                                <div className={`absolute ${arrowYClass} ${arrowXClass} w-3 h-3 transform rotate-45 rounded-[2px] ${arrowBgClass} z-[105]`}></div>
                            </div>
                        </div>
                    );
                })}
            </div>

            {/* Legend Section */}
            <div className="mt-8 flex flex-col lg:flex-row gap-6 lg:gap-12 justify-center items-stretch text-sm bg-white p-6 rounded-2xl shadow-sm border border-gray-100 w-full max-w-4xl mx-auto">
                {/* Status Legend */}
                <div className="flex flex-col sm:flex-row gap-4 items-center sm:items-stretch lg:border-r lg:border-gray-100 lg:pr-12">
                    <span className="font-extrabold text-gray-500 uppercase text-xs tracking-widest sm:border-r sm:border-gray-100 sm:pr-4 flex items-center">Status</span>
                    <div className="flex flex-wrap justify-center sm:justify-start gap-5">
                        <div className="flex items-center text-gray-700 font-semibold"><div className="w-5 h-5 bg-green-100 border border-green-200 rounded mr-2 shadow-sm"></div> Available</div>
                        <div className="flex items-center text-gray-700 font-semibold"><div className="w-5 h-5 bg-blue-500 rounded mr-2 shadow-sm"></div> Selected</div>
                        <div className="flex items-center text-gray-700 font-semibold"><div className="w-5 h-5 bg-gray-400 rounded mr-2 shadow-sm opacity-80"></div> Reserved</div>
                    </div>
                </div>
                
                {/* Horizontal divider for mobile */}
                <div className="block lg:hidden w-full h-px bg-gray-100"></div>

                {/* Pricing Legend */}
                <div className="flex flex-col sm:flex-row gap-4 items-center sm:items-stretch">
                    <span className="font-extrabold text-gray-500 uppercase text-xs tracking-widest sm:border-r sm:border-gray-100 sm:pr-4 flex items-center">Pricing</span>
                    <div className="flex flex-wrap justify-center sm:justify-start gap-6 sm:gap-8">
                        <div className="flex flex-col items-center sm:items-start text-center sm:text-left">
                            <span className="text-gray-900 font-extrabold text-base">Rs. {(stalls.find(s => s.size === 'SMALL')?.price || 5000).toLocaleString()}</span>
                            <span className="text-gray-500 text-[10px] sm:text-xs font-bold uppercase tracking-wider mt-0.5">Small</span>
                        </div>
                        <div className="flex flex-col items-center sm:items-start text-center sm:text-left">
                            <span className="text-gray-900 font-extrabold text-base">Rs. {(stalls.find(s => s.size === 'MEDIUM')?.price || 10000).toLocaleString()}</span>
                            <span className="text-gray-500 text-[10px] sm:text-xs font-bold uppercase tracking-wider mt-0.5">Medium</span>
                        </div>
                        <div className="flex flex-col items-center sm:items-start text-center sm:text-left">
                            <span className="text-gray-900 font-extrabold text-base">Rs. {(stalls.find(s => s.size === 'LARGE')?.price || 15000).toLocaleString()}</span>
                            <span className="text-gray-500 text-[10px] sm:text-xs font-bold uppercase tracking-wider mt-0.5">Large</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default StallMap;