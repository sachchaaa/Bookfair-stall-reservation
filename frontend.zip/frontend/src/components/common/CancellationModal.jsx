import React from 'react';

const CancellationModal = ({ isOpen, onClose, onConfirm }) => {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm transition-opacity">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden transform transition-all border border-amber-100">
                <div className="p-6">
                    <div className="flex items-center justify-center w-16 h-16 mx-auto bg-amber-100 rounded-full mb-6">
                        <svg className="w-8 h-8 text-amber-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
                        </svg>
                    </div>
                    
                    <h3 className="text-xl font-bold text-center pl-2 pr-2 text-gray-900 mb-2">
                        Cancellation Policy
                    </h3>
                    
                    <div className="bg-amber-50 border-l-4 border-amber-500 p-4 mt-4 rounded-r text-sm text-gray-700">
                        <p className="font-medium">Please note:</p>
                        <p className="mt-1">
                            Cancellations cannot be done automatically after payment. You will need to contact the Organizer directly.
                        </p>
                    </div>
                </div>

                <div className="bg-gray-50 px-6 py-4 flex flex-col sm:flex-row gap-3 justify-end">
                    <button
                        onClick={onClose}
                        className="w-full sm:w-auto px-5 py-2.5 text-sm font-semibold text-gray-700 bg-white border border-gray-300 rounded-xl hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-gray-200 transition-colors"
                    >
                        Cancel
                    </button>
                    <button
                        onClick={onConfirm}
                        className="w-full sm:w-auto px-5 py-2.5 text-sm font-semibold text-white bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl hover:from-blue-700 hover:to-indigo-700 shadow-md transform transition-all hover:-translate-y-0.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                        I Understand, Proceed to Payment
                    </button>
                </div>
            </div>
        </div>
    );
};

export default CancellationModal;
