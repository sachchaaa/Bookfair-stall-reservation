import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

const ProtectedRoute = ({ children, allowedRoles }) => {
    const { token, user } = useAuth();
    const location = useLocation();

    if (!token) {
        return <Navigate to="/login" state={{ from: location }} replace />;
    }

    // Wait for user details to be populated from token
    if (!user) {
        return null; // Or a loading spinner
    }

    if (allowedRoles && !allowedRoles.includes(user.role)) {
        toast.error('Access Denied: Unauthorized');
        // Redirect to appropriate login/dashboard based on their ACTUAL role
        const redirectTarget = user.role === 'VENDOR' ? '/dashboard' : '/admin';
        return <Navigate to={redirectTarget} replace />;
    }

    return children;
};

export default ProtectedRoute;
