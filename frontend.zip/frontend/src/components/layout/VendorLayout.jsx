import { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Outlet, Link, useLocation } from 'react-router-dom';
import LogoutModal from '../common/LogoutModal';
import api from '../../services/api';

const VendorLayout = () => {
    const { user, logout } = useAuth();
    const location = useLocation();
    const [isLogoutModalOpen, setIsLogoutModalOpen] = useState(false);
    const [totalStallsBooked, setTotalStallsBooked] = useState(0);

    // Default to 'Guest Vendor' if name isn't available
    const displayName = user?.businessName || 'Guest Vendor';

    // Fetch quota whenever location changes (e.g. returning to dashboard after checkout)
    useEffect(() => {
        const fetchQuota = async () => {
            try {
                const response = await api.get('/reservations/my');
                const reservations = response.data;

                let booked = 0;
                reservations.forEach(res => {
                    if (res.status !== 'CANCELLED') {
                        booked += res.stalls.length;
                    }
                });
                setTotalStallsBooked(booked);
            } catch (error) {
                console.error("Error fetching quota:", error);
            }
        };

        fetchQuota();
    }, [location.pathname]);

    const maxStalls = 3;
    const progressPercentage = (totalStallsBooked / maxStalls) * 100;

    const navLinks = [
        { path: '/dashboard', label: 'Dashboard' },
        { path: '/my-stalls', label: 'My Booked Stalls' },
    ];

    return (
        <div className="min-h-screen bg-gray-50 flex">
            {/* Sidebar */}
            <aside className="w-64 bg-white shadow-lg border-r border-gray-200 flex flex-col sticky top-0 h-screen">
                {/* Brand / Welcome area */}
                <div className="p-6 border-b border-gray-100 flex flex-col items-center justify-center text-center">
                    <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-3">
                        <span className="text-2xl font-bold text-blue-600">
                            {displayName.charAt(0).toUpperCase()}
                        </span>
                    </div>
                    <span className="text-lg font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent leading-tight">
                        {displayName}
                    </span>
                    <span className="text-xs text-gray-500 mt-1 uppercase tracking-wider font-semibold">Vendor Portal</span>
                </div>

                {/* Navigation Links */}
                <nav className="flex-1 px-4 py-8 space-y-3 overflow-y-auto">
                    {navLinks.map((link) => (
                        <Link
                            key={link.path}
                            to={link.path}
                            className={`flex items-center px-4 py-3 rounded-xl text-base font-semibold transition-all duration-200 ${location.pathname === link.path
                                ? 'bg-blue-50 text-blue-700 shadow-sm border border-blue-100'
                                : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900 border border-transparent'
                                }`}
                        >
                            {link.label}
                        </Link>
                    ))}
                </nav>

                {/* Quota Tracker */}
                <div className="p-4 mx-4 mb-4 bg-gray-50 border border-gray-100 rounded-xl">
                    <div className="flex justify-between items-center mb-2">
                        <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Stall Quota</span>
                        <span className="text-xs font-bold text-gray-700">
                            {totalStallsBooked} / {maxStalls}
                        </span>
                    </div>
                    <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div
                            className={`h-full rounded-full transition-all duration-500 ease-out ${totalStallsBooked >= maxStalls
                                ? 'bg-red-500'
                                : totalStallsBooked === 2
                                    ? 'bg-amber-500'
                                    : 'bg-green-500'
                                }`}
                            style={{ width: `${progressPercentage}%` }}
                        />
                    </div>
                </div>

                {/* Logout Action */}
                <div className="p-4 border-t border-gray-100">
                    <button
                        onClick={() => setIsLogoutModalOpen(true)}
                        className="w-full flex justify-center items-center px-4 py-2 text-sm font-semibold text-red-600 bg-red-50 hover:bg-red-100 rounded-xl transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2"
                    >
                        <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                        </svg>
                        Logout
                    </button>
                </div>
            </aside>

            {/* Main Content Area */}
            <main className="flex-1 flex flex-col min-w-0">
                <div className="flex-1 p-8 overflow-y-auto">
                    <div className="max-w-7xl mx-auto">
                        <Outlet />
                    </div>
                </div>
            </main>

            {/* Logout Modal Overlay */}
            <LogoutModal
                isOpen={isLogoutModalOpen}
                onClose={() => setIsLogoutModalOpen(false)}
                onConfirm={logout}
            />
        </div>
    );
};

export default VendorLayout;
