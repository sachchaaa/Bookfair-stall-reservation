import axios from 'axios';

const api = axios.create({
    baseURL: 'http://localhost:8080/api/v1',
    headers: {
        'Content-Type': 'application/json',
    },
});

api.interceptors.request.use(
    (config) => {
        const token = localStorage.getItem('token');
        if (token) {
            config.headers['Authorization'] = `Bearer ${token}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

export const getAdminStats = async () => {
    const response = await api.get('/admin/stats');
    return response.data;
};

export const getAllReservations = async () => {
    const response = await api.get('/admin/reservations');
    return response.data;
};

export const cancelReservation = async (id) => {
    const response = await api.put(`/admin/reservations/${id}/cancel`);
    return response.data;
};

export default api;