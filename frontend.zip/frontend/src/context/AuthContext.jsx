import { createContext, useState, useEffect, useContext } from 'react';
import { jwtDecode } from 'jwt-decode';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [token, setToken] = useState(localStorage.getItem('token'));

    const login = (newToken) => {
        localStorage.setItem('token', newToken);
        setToken(newToken);
    };

    const logout = () => {
        localStorage.removeItem('token');
        setToken(null);
        setUser(null);
    };

    useEffect(() => {
        if (token) {
            try {
                const decoded = jwtDecode(token);
                const currentTime = Date.now() / 1000;
                
                if (decoded.exp < currentTime) {
                    // Safe logout to prevent React render warnings
                    setTimeout(() => logout(), 0);
                } else {
                    setUser({
                        email: decoded.sub,
                        role: decoded.role || "VENDOR",
                        // Keeping the businessName extraction for the new Dashboard UI
                        businessName: decoded.businessName || null 
                    });
                }
            } catch (error) {
                setTimeout(() => logout(), 0);
            }
        }
    }, [token]);

    const hasRole = (role) => {
        return user?.role === role;
    };

    return (
        <AuthContext.Provider value={{ user, token, login, logout, hasRole }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => useContext(AuthContext);