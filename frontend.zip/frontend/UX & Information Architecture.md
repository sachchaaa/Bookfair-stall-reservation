# 🗺️ UX & Information Architecture

This document defines the **Global Structure** and **User Flows** for the Book Fair Stall Reservation System. We utilize a **Hierarchical Model** with strict role isolation to ensure a seamless experience for both Vendors and Employees.

---

## 🏗️ 1. The Global Structure

The application is divided into two distinct portals.

### 🏛️ Portal A: Vendor Application (Public & Protected)
Target Audience: *Book Publishers & Vendors*

*   **Level 0 (Public): Landing Page**
    *   Hero Section (Value Prop)
    *   About the Fair
    *   Pricing & Stall Maps
    *   👉 **Call to Action: Register/Login**

*   **Level 1 (Auth): Authentication**
    *   `/login` & `/register`

*   **Level 2 (Protected Hub): Vendor Dashboard** 🔒
    *   The central node for all vendor activities.
    *   **Branch 2.1: Booking Flow**
        *   Interactive Map (Select Stalls) ➔ Checkout ➔ Payment Confirmation
    *   **Branch 2.2: Management**
        *   My Reservations (List View) ➔ 🎫 Download Digital Pass (QR)
    *   **Branch 2.3: Catalog**
        *   Genre Management (Add/Edit Categories)

### 🏢 Portal B: Employee Application (Strictly Protected)
Target Audience: *Exhibition Organizers*

*   **Level 0 (Auth): Secure Login** 🛡️
    *   No public registration allowed.
*   **Level 1 (Command Center): Admin Dashboard**
    *   **Branch 1.1: Reservation Management**
        *   Master Table (View All) ➔ Cancel Action ❌
    *   **Branch 1.2: Availability Checker**
        *   Map View (Filter by Status: `AVAILABLE`, `RESERVED`)

### 🧠 Visual Hierarchy (Sitemap)

```mermaid
graph TD
    User((User))
    
    subgraph "Portal A: Vendor"
        Landing[Landing Page] --> Auth[Login / Register]
        Auth --> Dash[Vendor Dashboard]
        Dash --> Map[Interactive Map]
        Dash --> MyRes[My Reservations]
        Dash --> Genres[Genre Manager]
        Map --> Checkout[Checkout Flow]
        MyRes --> QR[Download QR Pass]
    end

    subgraph "Portal B: Employee"
        EmpLogin[Secure Login] --> AdminDash[Admin Dashboard]
        AdminDash --> ResMgmt[Reservation Mgmt]
        AdminDash --> Avail[Availability Map]
    end

    User --> Landing
    User --> EmpLogin
```

---

## 🔍 2. Hierarchical Task Analysis (HTA)

We analyzed the system from the **User's Perspective** to define the Critical Path: **Task 0. Book a Stall**.

### 🎯 The Critical Path

1.  **Authenticate Identity** 🆔
    *   1.1 Enter Business Name, Email, Password.
    *   1.2 Submit & Await Backend Validation.
2.  **Locate Suitable Stall** 📍
    *   2.1 View Interactive Exhibition Map.
    *   2.2 Filter by Size (Small, Medium, Large).
    *   2.3 Identify **AVAILABLE** (Green) vs **RESERVED** (Gray).
3.  **Execute Selection** ✅
    *   3.1 Click up to **3** available stalls.
    *   3.2 Review dynamic pricing.
4.  **Finalize Checkout** 💳
    *   4.1 Confirm selection in Modal.
    *   4.2 Await Transactional Commit.
5.  **Retrieve Entry Pass** 🎫
    *   5.1 View Success Screen.
    *   5.2 Download **HMAC-SHA256 Signed QR Code**.
    *   5.3 Input literary genres.

### ⏳ User Flow Diagram

```mermaid
sequenceDiagram
    actor Vendor
    participant FE as Frontend (React)
    participant API as Backend (Spring Boot)
    participant DB as Database

    Vendor->>FE: 1. Register / Login
    FE->>API: POST /auth/login
    API-->>FE: JWT Token

    Vendor->>FE: 2. View Map
    FE->>API: GET /stalls
    API->>DB: Fetch Status
    DB-->>API: Status List
    API-->>FE: Render Map (Green/Gray)

    Vendor->>FE: 3. Select Stalls & Checkout
    FE->>API: POST /reservations
    Note right of API: Transactional Boundary
    API->>DB: Lock Stalls (Optimistic)
    API->>DB: Save Reservation
    API-->>FE: 200 OK + Signed QR

    Vendor->>FE: 5. Download QR & Add Genres
```
