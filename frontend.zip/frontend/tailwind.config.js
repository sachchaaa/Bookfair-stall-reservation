/** @type {import('tailwindcss').Config} */
export default {
    content: [
        "./index.html",
        "./src/**/*.{js,jsx,ts,tsx}",
    ],
    theme: {
        extend: {
            colors: {
                primary: {
                    50: '#ebf5ff',
                    100: '#e1effe',
                    200: '#c3ddfd',
                    300: '#a4cbfc',
                    400: '#66a9f8',
                    500: '#3385f4',
                    600: '#296fd9',
                    700: '#1f55a7',
                    800: '#153974',
                    900: '#0b1f44',
                },
            },
            fontFamily: {
                sans: ['Inter', 'ui-sans-serif', 'system-ui'],
            },
        },
    },
    plugins: [],
}
