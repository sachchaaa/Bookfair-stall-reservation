package com.bookfair.backend.dto;

import lombok.Builder;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
public class ReservationResponse {
    private Long id;
    private UserSummaryDTO vendor;
    private List<StallDTO> stalls;
    private List<String> genres;
    private LocalDateTime reservationDate;
    private String status;
    private String qrToken;
}
