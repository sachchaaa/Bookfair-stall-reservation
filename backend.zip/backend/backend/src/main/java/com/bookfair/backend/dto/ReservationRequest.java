package com.bookfair.backend.dto;

import lombok.Data;
import java.util.List;
import jakarta.validation.constraints.NotEmpty;

@Data
public class ReservationRequest {
    @NotEmpty(message = "Must select at least one stall")
    private List<Long> stallIds;
}
