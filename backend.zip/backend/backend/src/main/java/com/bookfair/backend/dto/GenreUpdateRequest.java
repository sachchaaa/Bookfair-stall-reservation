package com.bookfair.backend.dto;

import lombok.Data;
import java.util.List;

@Data
public class GenreUpdateRequest {
    private List<String> genres;
}
