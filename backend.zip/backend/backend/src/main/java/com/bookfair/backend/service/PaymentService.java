package com.bookfair.backend.service;

import com.bookfair.backend.entity.Payment;
import com.bookfair.backend.entity.PaymentStatus;
import com.bookfair.backend.entity.Reservation;
import com.bookfair.backend.entity.ReservationStatus;
import com.bookfair.backend.repository.PaymentRepository;
import com.bookfair.backend.repository.ReservationRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final ReservationRepository reservationRepository;
    private final EmailService emailService;
    private final QrCodeService qrCodeService;

    @Transactional
    public Payment processPayment(Long reservationId, Double amount, String userEmail) {

        Reservation reservation = reservationRepository.findById(reservationId)
                .orElseThrow(() -> new RuntimeException("Reservation not found"));

        if (!reservation.getVendor().getEmail().equals(userEmail)) {
            throw new RuntimeException("You are not authorized to pay for this reservation");
        }

        if (reservation.getStatus() != ReservationStatus.PENDING) {
            throw new RuntimeException("This reservation is not in PENDING status");
        }

        Payment payment = Payment.builder()
                .reservation(reservation)
                .amount(amount)
                .status(PaymentStatus.PAID)
                .build();

        paymentRepository.save(payment);

        reservation.setStatus(ReservationStatus.CONFIRMED);
        reservation.setQrToken(java.util.UUID.randomUUID().toString());
        reservationRepository.save(reservation);

        try {
            byte[] qrImage = qrCodeService.generateQrCodeImage(reservation.getQrToken(), 300, 300);
            emailService.sendQrCodeEmail(userEmail, reservation.getId().toString(), qrImage);
        } catch (Exception e) {
            System.err.println("Payment succeeded, but email failed to send: " + e.getMessage());
        }

        return payment;
    }
}
