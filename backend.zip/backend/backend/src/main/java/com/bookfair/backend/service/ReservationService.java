package com.bookfair.backend.service;

import com.bookfair.backend.entity.*;
import com.bookfair.backend.repository.ReservationRepository;
import com.bookfair.backend.repository.StallRepository;
import com.bookfair.backend.repository.UserRepository;
import org.springframework.transaction.annotation.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.bookfair.backend.dto.ReservationResponse;
import com.bookfair.backend.dto.StallDTO;
import com.bookfair.backend.dto.UserSummaryDTO;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;

@Service
@RequiredArgsConstructor
public class ReservationService {

    private final ReservationRepository reservationRepository;
    private final StallRepository stallRepository;
    private final UserRepository userRepository;

    @Transactional // Ensures if one step fails, EVERYTHING rolls back
    public ReservationResponse createReservation(String userEmail, List<Long> stallIds) {

        User vendor = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        if (vendor.getRole() != Role.VENDOR) {
            throw new RuntimeException("Only Vendors can book stalls!");
        }

        // 1. Check Global Limit (Max 3 stalls per vendor TOTAL)
        List<Reservation> existingReservations = reservationRepository.findByVendorId(vendor.getId());

        long totalOwnedStalls = existingReservations.stream()
                .mapToLong(res -> res.getStalls().size())
                .sum();

        // Security Fix: Deduplicate Input IDs to prevent bypass
        List<Long> distinctStallIds = stallIds.stream().distinct().collect(Collectors.toList());

        if (totalOwnedStalls + distinctStallIds.size() > 3) {
            long remaining = 3 - totalOwnedStalls;
            throw new RuntimeException("Limit exceeded! You already own " + totalOwnedStalls
                    + " stalls. You can only book " + remaining + " more.");
        }

        List<Stall> stallsToBook = stallRepository.findAllById(distinctStallIds);
        if (stallsToBook.size() != distinctStallIds.size()) {
            throw new RuntimeException("Some stalls ID are invalid!");
        }

        for (Stall stall : stallsToBook) {
            // Concurrency: @Version in Stall entity will handle the race condition here on
            // save
            if (stall.getStatus() == StallStatus.RESERVED) {
                throw new RuntimeException("Stall " + stall.getName() + " is already reserved!");
            }
            stall.setStatus(StallStatus.RESERVED);
        }

        stallRepository.saveAll(stallsToBook);

        // Security Fix: Generate Signed QR Token
        String signedQrToken = generateSignedQrToken(vendor.getId(), distinctStallIds);

        Reservation reservation = Reservation.builder()
                .vendor(vendor)
                .stalls(stallsToBook)
                .reservationDate(LocalDateTime.now())
                .status(ReservationStatus.PENDING)
                .qrToken(signedQrToken)
                .build();

        Reservation savedReservation = reservationRepository.save(reservation);
        return mapToDTO(savedReservation);
    }

    @Transactional(readOnly = true)
    public List<ReservationResponse> getMyReservations(String email) {
        User user = userRepository.findByEmail(email).orElseThrow();
        List<Reservation> reservations = reservationRepository.findByVendorId(user.getId());
        return reservations.stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    @Transactional
    public void updateGenres(Long reservationId, List<String> genres) {
        if (genres == null || genres.isEmpty()) {
            throw new RuntimeException("At least one genre must be selected!");
        }

        Reservation reservation = reservationRepository.findById(reservationId)
                .orElseThrow(() -> new RuntimeException("Reservation not found"));

        reservation.setGenres(genres);
        reservationRepository.save(reservation);
    }

    @Transactional(readOnly = true)
    public java.util.Map<String, Object> getDashboardStats() {
        long totalStalls = stallRepository.count();
        long availableStalls = stallRepository.countByStatus(StallStatus.AVAILABLE);
        long bookedStalls = totalStalls - availableStalls;

        // Calculate Revenue
        List<Stall> reservedStalls = stallRepository.findByStatus(StallStatus.RESERVED);
        java.math.BigDecimal totalRevenue = java.math.BigDecimal.ZERO;

        for (Stall stall : reservedStalls) {
            if (stall.getPrice() != null) {
                totalRevenue = totalRevenue.add(java.math.BigDecimal.valueOf(stall.getPrice()));
            }
        }

        return java.util.Map.of(
                "totalStalls", totalStalls,
                "bookedStalls", bookedStalls,
                "availableStalls", availableStalls,
                "totalRevenue", totalRevenue);
    }

    @Transactional(readOnly = true)
    public Page<ReservationResponse> getAllReservations(Pageable pageable) {
        Page<Reservation> reservations = reservationRepository.findAll(pageable);
        return reservations.map(this::mapToDTO);
    }

    @Transactional
    public void cancelReservation(Long id) {
        Reservation reservation = reservationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Reservation not found"));

        if (reservation.getStatus() == ReservationStatus.CANCELLED) {
            throw new RuntimeException("Reservation is already cancelled");
        }

        // 1. Update Reservation Status
        reservation.setStatus(ReservationStatus.CANCELLED);

        // 2. Free up Stalls
        for (Stall stall : reservation.getStalls()) {
            stall.setStatus(StallStatus.AVAILABLE);
        }
        stallRepository.saveAll(reservation.getStalls());

        reservationRepository.save(reservation);
    }

    private ReservationResponse mapToDTO(Reservation res) {
        return ReservationResponse.builder()
                .id(res.getId())
                .vendor(UserSummaryDTO.builder()
                        .id(res.getVendor().getId())
                        .email(res.getVendor().getEmail())
                        .businessName(res.getVendor().getBusinessName())
                        .build())
                .stalls(res.getStalls().stream()
                        .map(s -> StallDTO.builder()
                                .id(s.getId())
                                .name(s.getName())
                                .size(s.getSize())
                                .status(s.getStatus())
                                .build())
                        .collect(Collectors.toList()))
                .genres(res.getGenres())
                .reservationDate(res.getReservationDate())
                .status(res.getStatus().name())
                .qrToken(res.getQrToken())
                .build();
    }

    private String generateSignedQrToken(Long vendorId, List<Long> stallIds) {
        try {
            String data = vendorId + ":" + stallIds.toString() + ":" + System.currentTimeMillis();
            Mac mac = Mac.getInstance("HmacSHA256");
            String secret = "s3cr3t-k3y-f0r-qr-c0d3s-ch@ng3-m3"; // In production, move to properties
            SecretKeySpec secretKeySpec = new SecretKeySpec(secret.getBytes(), "HmacSHA256");
            mac.init(secretKeySpec);
            byte[] hmacData = mac.doFinal(data.getBytes());
            return Base64.getEncoder().encodeToString(hmacData);
        } catch (Exception e) {
            throw new RuntimeException("Error generating QR Token", e);
        }
    }
}
