package com.bookfair.backend.service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class EmailService {

    private final JavaMailSender mailSender;

    public void sendQrCodeEmail(String toEmail, String reservationId, byte[] qrCodeImage) {
        try {
            MimeMessage message = mailSender.createMimeMessage();

            MimeMessageHelper helper = new MimeMessageHelper(message, true);

            helper.setTo(toEmail);
            helper.setSubject("Book Fair - Reservation Confirmed! ID: #" + reservationId);
            helper.setText(
                    "Dear Vendor,\n\nYour payment was successful and your reservation is confirmed!\n\nPlease find your entrance QR Code attached to this email. Show this at the exhibition gate.\n\nThank you,\nBook Fair Team");

            helper.addAttachment("Reservation-QR-" + reservationId + ".png", new ByteArrayResource(qrCodeImage));

            mailSender.send(message);
            System.out.println("✅ Email successfully sent to: " + toEmail);

        } catch (MessagingException e) {
            System.err.println("❌ Failed to send email: " + e.getMessage());
            throw new RuntimeException("Failed to send confirmation email");
        }
    }

    public void sendPasswordResetEmail(String toEmail, String token) {
        String resetLink = "http://localhost:5173/reset-password?token=" + token;
        try {
            // Mocking email sending for development
            // MimeMessage message = mailSender.createMimeMessage();
            // MimeMessageHelper helper = new MimeMessageHelper(message, true);

            // helper.setTo(toEmail);
            // helper.setSubject("Book Fair - Password Reset Request");
            // helper.setText(...);

            // mailSender.send(message);
            System.out.println("==================================================");
            System.out.println("📧 [MOCK EMAIL] To: " + toEmail);
            System.out.println("🔗 Reset Link: " + resetLink);
            System.out.println("==================================================");
            
        } catch (Exception e) {
            System.err.println("❌ Failed to mock email: " + e.getMessage());
        }
    }
}