package com.bookfair.backend.entity;

public enum StallStatus {
    AVAILABLE,
    RESERVED
}
