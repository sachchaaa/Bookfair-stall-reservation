package com.bookfair.backend.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "reservations")
public class Reservation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User vendor;

    @ManyToMany
    @JoinTable(name = "reservation_stalls", joinColumns = @JoinColumn(name = "reservation_id"), inverseJoinColumns = @JoinColumn(name = "stall_id"))
    private List<Stall> stalls;

    @ElementCollection
    @CollectionTable(name = "reservation_genres", joinColumns = @JoinColumn(name = "reservation_id"))
    @Column(name = "genre")
    private List<String> genres;

    private LocalDateTime reservationDate;

    @Enumerated(EnumType.STRING)
    private ReservationStatus status;

    @Column(name = "qr_token", unique = true)
    private String qrToken;
}
