package com.bookfair.backend.repository;

import com.bookfair.backend.entity.Reservation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface ReservationRepository extends JpaRepository<Reservation, Long> {

    // Find all reservations for a specific vendor
    List<Reservation> findByVendorId(Long vendorId);

    // Custom Query: Find all reservations for a specific vendor by email
    @Query("SELECT r FROM Reservation r JOIN r.vendor v WHERE v.email = :email")
    List<Reservation> findByVendorEmail(@Param("email") String email);

    // Custom Query: Check if a specific stall is already booked in an ACTIVE
    // reservation
    @Query("SELECT CASE WHEN COUNT(r) > 0 THEN true ELSE false END FROM Reservation r JOIN r.stalls s WHERE s.id = :stallId AND r.status != 'CANCELLED'")
    boolean isStallReserved(@Param("stallId") Long stallId);
}
