package com.bookfair.backend.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "stalls")
public class Stall {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Version
    private Long version;

    @Column(nullable = false, unique = true)
    private String name; //A1 ,B2

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Size size;

    // Coordinates for the Frontend Map (Grid System)
    @Column(name = "map_x")
    private Integer mapX;

    @Column(name = "map_y")
    private Integer mapY;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private StallStatus status = StallStatus.AVAILABLE;

    @Column(nullable = false)
    @Builder.Default
    private Double price = 0.0;
}