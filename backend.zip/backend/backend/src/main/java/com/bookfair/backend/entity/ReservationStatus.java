package com.bookfair.backend.entity;

public enum ReservationStatus {
    PENDING,
    CONFIRMED,
    CANCELLED
}
