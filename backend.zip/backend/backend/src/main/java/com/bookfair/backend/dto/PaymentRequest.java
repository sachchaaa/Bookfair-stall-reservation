package com.bookfair.backend.dto;

import lombok.Data;

@Data
public class PaymentRequest {
    private Long reservationId;
    private Double amount;
}
