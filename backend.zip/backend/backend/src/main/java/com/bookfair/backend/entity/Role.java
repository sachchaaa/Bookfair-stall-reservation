package com.bookfair.backend.entity;

public enum Role {
    VENDOR,
    EMPLOYEE,
}
