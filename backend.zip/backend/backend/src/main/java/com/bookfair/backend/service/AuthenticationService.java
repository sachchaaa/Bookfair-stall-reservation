package com.bookfair.backend.service;

import com.bookfair.backend.dto.AuthenticationRequest;
import com.bookfair.backend.dto.AuthenticationResponse;
import com.bookfair.backend.dto.RegisterRequest;
import com.bookfair.backend.entity.User;
import com.bookfair.backend.repository.UserRepository;
import com.bookfair.backend.security.JwtService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class AuthenticationService {

        private final UserRepository repository;
        private final PasswordEncoder passwordEncoder;
        private final JwtService jwtService;

        private final AuthenticationManager authenticationManager;
        private final EmailService emailService;

        @Transactional
        public AuthenticationResponse register(RegisterRequest request) {
                var user = User.builder()
                                .email(request.getEmail())
                                .password(passwordEncoder.encode(request.getPassword()))
                                .role(request.getRole())
                                .businessName(request.getBusinessName())
                                .build();

                repository.save(user);

                var jwtToken = jwtService.generateToken(user);
                return AuthenticationResponse.builder()
                                .token(jwtToken)
                                .role(user.getRole().name())
                                .businessName(user.getBusinessName())
                                .build();
        }

        @Transactional(readOnly = true)
        public AuthenticationResponse authenticate(AuthenticationRequest request) {
                authenticationManager.authenticate(
                                new UsernamePasswordAuthenticationToken(
                                                request.getEmail(),
                                                request.getPassword()));

                var user = repository.findByEmail(request.getEmail())
                                .orElseThrow();

                var jwtToken = jwtService.generateToken(user);
                return AuthenticationResponse.builder()
                                .token(jwtToken)
                                .role(user.getRole().name())
                                .businessName(user.getBusinessName())
                                .build();
        }

        @Transactional
        public void forgotPassword(String email) {
                var user = repository.findByEmail(email)
                                .orElseThrow(() -> new RuntimeException("User not found with email: " + email));

                String token = UUID.randomUUID().toString();
                user.setResetToken(token);
                user.setResetTokenExpiry(LocalDateTime.now().plusMinutes(15));

                repository.save(user);

                emailService.sendPasswordResetEmail(user.getEmail(), token);
        }

        @Transactional
        public void resetPassword(String token, String newPassword) {
                var user = repository.findByResetToken(token)
                                .orElseThrow(() -> new RuntimeException("Invalid reset token"));

                if (user.getResetTokenExpiry().isBefore(LocalDateTime.now())) {
                        throw new RuntimeException("Reset token has expired");
                }

                user.setPassword(passwordEncoder.encode(newPassword));
                user.setResetToken(null);
                user.setResetTokenExpiry(null);

                repository.save(user);
        }
}