package com.bookfair.backend.config;

import com.bookfair.backend.entity.Size;
import com.bookfair.backend.entity.Stall;
import com.bookfair.backend.entity.StallStatus;
import com.bookfair.backend.repository.StallRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
@RequiredArgsConstructor
public class DataSeeder implements CommandLineRunner {

    private final StallRepository stallRepository;

    @Override
    public void run(String... args) throws Exception {
        if (stallRepository.count() == 0) {
            List<Stall> stalls = new ArrayList<>();

            //10x5 Grid
            for (int row = 0; row < 5; row++) {
                for (int col = 0; col < 10; col++) {
                    String name = (char)('A' + row) + String.valueOf(col + 1);

                    Size size = Size.SMALL;
                    if (col % 3 == 0) size = Size.MEDIUM;
                    if (col % 5 == 0) size = Size.LARGE;

                    Stall stall = Stall.builder()
                            .name(name)
                            .size(size)
                            .mapX(col)
                            .mapY(row)
                            .status(StallStatus.AVAILABLE)
                            .price(
                                    size == Size.SMALL ? 5000.0 :
                                            size == Size.MEDIUM ? 10000.0 : 15000.0
                            )
                            .build();
                    stalls.add(stall);
                }
            }
            stallRepository.saveAll(stalls);
            System.out.println("Database seeded with " + stalls.size() + " stalls");
        }
    }
}