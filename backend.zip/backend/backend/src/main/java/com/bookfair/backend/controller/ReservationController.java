package com.bookfair.backend.controller;

import com.bookfair.backend.dto.ReservationRequest;
import com.bookfair.backend.dto.ReservationResponse;
import com.bookfair.backend.dto.GenreUpdateRequest;
import com.bookfair.backend.service.ReservationService;
import lombok.RequiredArgsConstructor;
import com.bookfair.backend.service.QrCodeService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/v1/reservations")
@RequiredArgsConstructor
public class ReservationController {

    private final ReservationService service;
    private final QrCodeService qrCodeService;



    @PostMapping
    public ResponseEntity<?> createReservation(
            @RequestBody @Valid ReservationRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        try {
            ReservationResponse reservation = service.createReservation(userDetails.getUsername(), request.getStallIds());
            return ResponseEntity.ok(reservation);
        } catch (org.springframework.orm.ObjectOptimisticLockingFailureException | org.springframework.dao.PessimisticLockingFailureException e) {
            return ResponseEntity.status(org.springframework.http.HttpStatus.CONFLICT)
                    .body("Stall(s) already reserved by another user. Please refresh and try again.");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/my")
    public ResponseEntity<List<ReservationResponse>> getMyReservations(
            @AuthenticationPrincipal UserDetails userDetails) {
        return ResponseEntity.ok(service.getMyReservations(userDetails.getUsername()));
    }

    @GetMapping(value = "/{id}/qr", produces = MediaType.IMAGE_PNG_VALUE)
    public ResponseEntity<byte[]> getReservationQr(@PathVariable("id") Long id) {
        String dummyToken = "BOOKFAIR-RESERVATION-" + id;
        byte[] image = qrCodeService.generateQrCodeImage(dummyToken, 250, 250);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"qr-" + id + ".png\"")
                .body(image);
    }

    @PutMapping("/{id}/genres")
    public ResponseEntity<?> updateGenres(
            @PathVariable("id") Long id,
            @RequestBody GenreUpdateRequest request) {
        service.updateGenres(id, request.getGenres());
        return ResponseEntity.ok("Genres updated successfully");
    }
}
