package com.bookfair.backend.repository;

import com.bookfair.backend.entity.Stall;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StallRepository extends JpaRepository<Stall, Long> {
    long countByStatus(com.bookfair.backend.entity.StallStatus status);

    java.util.List<Stall> findByStatus(com.bookfair.backend.entity.StallStatus status);

}