package com.bookfair.backend.dto;

import com.bookfair.backend.entity.Size;
import com.bookfair.backend.entity.StallStatus;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class StallDTO {
    private Long id;
    private String name;
    private Size size;
    private StallStatus status;
    private Double price;
}
