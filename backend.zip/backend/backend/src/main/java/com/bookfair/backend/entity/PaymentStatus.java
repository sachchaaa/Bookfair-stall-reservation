package com.bookfair.backend.entity;

public enum PaymentStatus {
    PENDING,
    PAID
}
