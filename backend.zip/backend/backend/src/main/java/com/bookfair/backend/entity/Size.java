package com.bookfair.backend.entity;

public enum Size {
    SMALL,
    MEDIUM,
    LARGE
}