package com.bookfair.backend.controller;

import com.bookfair.backend.entity.Stall;
import com.bookfair.backend.repository.StallRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/stalls")
@RequiredArgsConstructor
public class StallController {

    private final StallRepository repository;

    @GetMapping
    public ResponseEntity<List<Stall>> getAllStalls() {
        return ResponseEntity.ok(repository.findAll());
    }
}